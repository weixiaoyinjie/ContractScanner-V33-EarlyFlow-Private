/* V32: independent 1-minute research pre-alert. No trading or background execution. */
(function(root){
'use strict';
const N=x=>x===null||x===undefined||x===''?NaN:Number(x);
const valid=Number.isFinite;
const pct=(newVal,oldVal)=>valid(newVal)&&valid(oldVal)&&oldVal>0?100*(newVal/oldVal-1):NaN;
const sum=values=>values.reduce((t,x)=>t+x,0);
const fail=(symbol,state,why,now)=>({symbol,state,score:null,risks:[why],reasons:[],when:now});
function clean(raw,now){
 if(!Array.isArray(raw))return [];
 return raw.filter(x=>x&&valid(N(x.t))&&N(x.t)>0&&(N(x.t)+60)*1000<=now)
  .sort((a,b)=>N(a.t)-N(b.t));
}
function choose(rows,now){
 if(!Array.isArray(rows))return [];
 const selected=[];
 for(const r of rows){
  if(!r||!/^[A-Z0-9]{2,24}USDT$/.test(r.symbol)||['BTCUSDT','ETHUSDT','BNBUSDT'].includes(r.symbol))continue;
  if(!valid(r.sampledAt)||now-r.sampledAt>60000||r.sampledAt>now+3000)continue;
  if(![r.p5,r.p15,r.p24,r.oi5,r.oi15,r.buy5,r.cvd5,r.oiUsd,r.maxBody5].every(valid))continue;
  if(Math.abs(r.p5)>1.15||Math.abs(r.p15)>2.8||Math.abs(r.p24)>12||r.maxBody5>=1.3||r.oiUsd<1_500_000)continue;
  if(valid(r.maxRange5)&&r.maxRange5>5.5)continue;
  if(valid(r.volPulse5)&&r.volPulse5>4.5)continue;
  if(valid(r.rise20)&&r.rise20>8)continue;
  if(valid(r.maxBull15)&&r.maxBull15>2.4)continue;
  if(r.oi5<-.25||r.oi15<-.35||r.buy5<45)continue;
  const rank=Math.max(-5,Math.min(14,r.oi5*6))+Math.max(-5,Math.min(10,r.oi15*2))+
   Math.max(-4,Math.min(8,(r.buy5-50)*1.2))+Math.max(-3,Math.min(7,r.cvd5))+
   (r.p5>=-.3&&r.p5<=.7?7:0)+(r.oiUsd>=5_000_000?4:0)+
   (valid(r.volPulse5)&&r.volPulse5>=1.05&&r.volPulse5<=2.5?4:0);
  selected.push({row:r,rank});
 }
 return selected.sort((a,b)=>b.rank-a.rank).slice(0,4);
}
function evaluate(row,oiRaw,ohlcvRaw,btc,now){
 const symbol=row?.symbol||'UNKNOWN';
 if(!row||!valid(row.sampledAt)||now-row.sampledAt>60000||row.sampledAt>now+3000)
  return fail(symbol,'数据过期','Binance初筛快照过期；请刷新',now);
 let oi=clean(oiRaw,now),v=clean(ohlcvRaw,now);
 const oiByTime=new Map(oi.map(x=>[N(x.t),x]));
 let common=v.filter(x=>oiByTime.has(N(x.t))).map(x=>({t:N(x.t),o:oiByTime.get(N(x.t)),v:x}));
 if(common.length<10)return fail(symbol,'数据不足','需要至少10根时间对齐的已收盘1分钟OI和OHLCV',now);
 common=common.slice(-20);
 const tail=common.slice(-10),last=tail.at(-1);
 if(now-(last.t+60)*1000>180000||last.t+60>now/1000+1)
  return fail(symbol,'数据过期','最新完整1分钟K线超过3分钟',now);
 if(tail.some((x,i)=>i>0&&x.t-tail[i-1].t!==60))
  return fail(symbol,'数据不足','1分钟K线存在缺口，不能比较连续资金变化',now);
 const oiCloses=tail.map(x=>N(x.o.c)),price=tail.map(x=>N(x.v.c));
 const vols=tail.map(x=>N(x.v.v)),buys=tail.map(x=>N(x.v.bv));
 if(oiCloses.some(x=>!valid(x)||x<=0)||price.some(x=>!valid(x)||x<=0)||
    vols.some(x=>!valid(x)||x<=0)||buys.some((x,i)=>!valid(x)||x<0||x>vols[i]*1.001))
  return fail(symbol,'数据不足','OI、成交量或主动买入量缺失/异常',now);
 const oi1=pct(oiCloses.at(-1),oiCloses.at(-2)),oi3=pct(oiCloses.at(-1),oiCloses.at(-4));
 const prevOi3=pct(oiCloses.at(-4),oiCloses.at(-7)),p1=pct(price.at(-1),price.at(-2)),p3=pct(price.at(-1),price.at(-4));
 const last3v=sum(vols.slice(-3)),prev3v=sum(vols.slice(-6,-3)),last3b=sum(buys.slice(-3));
 const prev3b=sum(buys.slice(-6,-3)),buy3=100*last3b/last3v;
 // Increment of aggressive buyer volume minus seller volume. NOT all-venue CVD.
 const net3=2*last3b-last3v,prevNet3=2*prev3b-prev3v;
 const volumePulse=last3v/prev3v;
 const cvdUp=net3>0&&net3>prevNet3;
 const oiAccelerating=oi3>prevOi3&&oi1>0;
 const lead=oi3>Math.abs(p3)*1.25&&oi3>=.25;
 let risks=[],reasons=[],score=0;
 if(oi3>=.32){score+=20;reasons.push('近3分钟OI '+oi3.toFixed(2)+'%')}
 else risks.push('近3分钟OI新增不足');
 if(oi1>=.07){score+=10;reasons.push('最近1分钟OI '+oi1.toFixed(2)+'%')}
 if(oiAccelerating){score+=10;reasons.push('OI较前3分钟加速')}
 if(buy3>=54){score+=15;reasons.push('近3分钟主动买入占比 '+buy3.toFixed(1)+'%')}
 else risks.push('主动买入优势不足');
 if(cvdUp){score+=10;reasons.push('近3分钟主动成交差额改善')}
 else risks.push('主动买卖差额未改善');
 if(volumePulse>=1.05&&volumePulse<=2.8){score+=10;reasons.push('成交量温和放大 '+volumePulse.toFixed(2)+'倍')}
 if(lead){score+=10;reasons.push('OI增长领先价格变化')}
 if(p3>=-.3&&p3<=.8&&Math.abs(p1)<=.65){score+=15;reasons.push('价格尚未明显加速')}
 else risks.push('1m/3m价格已偏离提前启动窗口');
 if(volumePulse>3.5)risks.push('1分钟量能异常爆发，谨防追尾');
 if(oi1<=0||oi3<=0)risks.push('1分钟OI回落或未增长');
 if(buy3<51||!cvdUp)risks.push('主动成交未确认多头占优');
 if(!btc||btc.healthy!==true||btc.shock===true||!valid(btc.p5)||btc.p5<=-.65)
  risks.push('BTC环境不允许确认做多');
 if(![row.p5,row.p15,row.p24,row.oiUsd].every(valid)||Math.abs(row.p5)>1.35||Math.abs(row.p15)>3.2||Math.abs(row.p24)>15||row.oiUsd<1_500_000)
  risks.push('价格或流动性前置过滤失败');
 if(row.oi5<-.25||row.oi15<-.35||row.buy5<45)risks.push('Binance中期结构与1m信号冲突');
 const hard=risks.some(s=>/BTC|回落|偏离|前置过滤|主动成交未确认|异常爆发|冲突/.test(s));
 const state=hard?'暂不入选':score>=75&&oi1>=.07&&oi3>=.32&&buy3>=54&&cvdUp&&lead?'1m重点复核':score>=55?'1m继续观察':'暂不入选';
 return {symbol,state,score,oi1,oi3,prevOi3,p1,p3,buy3,net3,prevNet3,volumePulse,cvdUp,
  oiAccelerating,lead,when:now,candleCloseAt:(last.t+60)*1000,reasons,risks,
  source:'Coinalyze · Binance USDT永续 · 仅已收盘1m OI/OHLCV'};
}
const api={choose,evaluate,clean,pct};root.MinuteCore=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
