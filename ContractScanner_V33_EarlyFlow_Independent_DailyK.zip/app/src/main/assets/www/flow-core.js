/* FlowPlus V31: pure, independently testable research engine. No original scanner mutations. */
(function(root){
'use strict';
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const num=x=>x===null||x===undefined||x===''?NaN:Number(x);
const change=(a,b)=>finite(a)&&finite(b)&&b>0?100*(a/b-1):null;
const closed=(data,seconds,now)=>Array.isArray(data)?data.filter(x=>finite(num(x.t))&&num(x.t)*1000+seconds*1000<=now).sort((a,b)=>num(a.t)-num(b.t)):[];
const last=a=>a[a.length-1];
function choose(baseline,now){
 if(!Array.isArray(baseline))return [];
 const out=[];
 for(const r of baseline){
  if(!r||!/^[A-Z0-9]{2,24}USDT$/.test(r.symbol)||['BTCUSDT','ETHUSDT','BNBUSDT'].includes(r.symbol))continue;
  if(!finite(r.sampledAt)||now-r.sampledAt>60_000||now<r.sampledAt-3000)continue;
  if(![r.p5,r.p15,r.p24,r.oi5,r.oi15,r.buy5,r.cvd5,r.oiUsd,r.maxBody5].every(finite))continue;
  if(Math.abs(r.p5)>1.35||Math.abs(r.p15)>3.2||Math.abs(r.p24)>15||r.maxBody5>=1.35||r.oiUsd<1_500_000)continue;
  if(r.oi5<=0.15||r.oi15<=0.2)continue;
  if(finite(r.maxRange5)&&r.maxRange5>5.5)continue;
  if(finite(r.volPulse5)&&r.volPulse5>5)continue;
  if(finite(r.rise20)&&r.rise20>9)continue;
  if(finite(r.maxBull15)&&r.maxBull15>2.4)continue;
  let score=Math.min(15,Math.max(0,r.oi5*4))+Math.min(10,Math.max(0,r.oi15*1.8))+
    Math.min(6,Math.max(0,(r.buy5-50)*1.4))+Math.min(5,Math.max(0,r.cvd5))+
    (r.p5>=-.4&&r.p5<=.85?8:0)+(r.oi5>Math.abs(r.p5)*1.5?8:0)+
    (r.oiUsd>=5_000_000?5:0)+(r.volPulse5>=1.05&&r.volPulse5<=2.8?4:0);
  out.push({row:r,preScore:score});
 }
 return out.sort((a,b)=>b.preScore-a.preScore).slice(0,30);
}
function mapMarkets(markets,symbol){
 if(!Array.isArray(markets))return null;
 const eligible=markets.filter(m=>m&&m.symbol_on_exchange===symbol&&m.is_perpetual===true&&
   (m.quote_asset==='USDT'||m.quote_asset==null)&&m.margined==='STABLE'&&
   (String(m.exchange||'').toUpperCase().includes('BINANCE')||String(m.symbol||'').endsWith('.A')));
 eligible.sort((a,b)=>(String(a.symbol||'').endsWith('.A')?0:1)-(String(b.symbol||'').endsWith('.A')?0:1));
 return eligible[0]?.symbol||null;
}
function evaluate(row,oi5raw,oi15raw,volraw,btc,now){
 let reasons=[],risks=[];
 let h5=closed(oi5raw,300,now),h15=closed(oi15raw,900,now),hv=closed(volraw,300,now);
 if(h5.length<4||h15.length<3||hv.length<6)return {symbol:row.symbol,state:'数据不足',score:null,reasons:[],risks:['Coinalyze历史记录不足，禁止标为资金确认'],when:now};
 // Missing time buckets must not be treated as consecutive observations.
 const consecutive=(items,sec,n)=>items.slice(-n).every((x,i,tail)=>i===0||num(x.t)-num(tail[i-1].t)===sec);
 if(!consecutive(h5,300,4)||!consecutive(h15,900,3)||!consecutive(hv,300,6))
  return {symbol:row.symbol,state:'数据不足',score:null,reasons:[],risks:['OI或主动成交历史存在缺口；禁止拼接跨时段资金变化'],when:now};
 // Reject stale snapshots (not a substitute for real-time trade feed).
 if(now-(num(last(h5).t)+300)*1000>8*60_000||now-(num(last(hv).t)+300)*1000>8*60_000||now-(num(last(h15).t)+900)*1000>20*60_000)
  return {symbol:row.symbol,state:'数据过期',score:null,reasons:[],risks:['Coinalyze更新延迟，禁止使用旧信号'],when:now};
 let c5=h5.map(x=>num(x.c)),c15=h15.map(x=>num(x.c));
 if([...c5,...c15].some(x=>!finite(x)||x<=0))return {symbol:row.symbol,state:'数据不足',score:null,reasons:[],risks:['OI历史含缺失值'],when:now};
 let oi5=change(last(c5),c5.at(-2)),oi15=change(last(c15),c15.at(-2));
 // OHLCV 'bv' (buy volume) and 'v' are same-denomination volumes in Coinalyze response.
 let flow=hv.map(x=>({t:num(x.t),buy:num(x.bv),total:num(x.v)}));
 if(flow.some(x=>!finite(x.total)||x.total<=0||!finite(x.buy)||x.buy<0||x.buy>x.total*1.001))
  return {symbol:row.symbol,state:'数据不足',score:null,reasons:[],risks:['主动买量缺失或与总量单位不一致'],when:now};
 let buy5=100*last(flow).buy/last(flow).total;
 let last3=flow.slice(-3),prev3=flow.slice(-6,-3),sum=a=>a.reduce((s,x)=>s+x,0);
 let net3=sum(last3.map(x=>2*x.buy-x.total)),netPrev=sum(prev3.map(x=>2*x.buy-x.total));
 let last3Volume=sum(last3.map(x=>x.total)),prev3Volume=sum(prev3.map(x=>x.total));
 let cvdProgress=net3>0&&last3Volume>0&&prev3Volume>0&&(net3/last3Volume)>(netPrev/prev3Volume);
 let volPulse=last(flow).total/(sum(flow.slice(-6,-1).map(x=>x.total))/5);
 let score=0;
 if(oi5>=.45){score+=12;reasons.push('Coinalyze 5m OI新增 '+oi5.toFixed(2)+'%')}
 if(oi15>=.75){score+=10;reasons.push('15m OI持续 '+oi15.toFixed(2)+'%')}
 if(oi5>Math.abs(row.p5)*1.25&&oi5>=.35)score+=8;
 if(buy5>=52){score+=12;reasons.push('主动买入占比 '+buy5.toFixed(1)+'%')}
 if(cvdProgress){score+=10;reasons.push('近三根5m主动成交差额改善')}
 if(volPulse>=1.08&&volPulse<=2.8)score+=8;
 if(row.p5>=-.3&&row.p5<=.95)score+=10;
 if(row.volPulse5>=1&&row.volPulse5<=3)score+=8;
 if(row.p15>=-.9&&row.p15<=2.5)score+=7;
 // Do not add a second score bonus for the same 15m OI threshold.
 if(last(c5)>c5.at(-2)&&c5.at(-2)>=c5.at(-3))score+=6;
 if(oi5<0.1||oi15<0){risks.push('Coinalyze OI未持续增长')}
 if(row.buy5<49.5||buy5<50)risks.push('Binance/Coinalyze主动买盘不一致或弱势');
 if(!cvdProgress)risks.push('近三根主动成交差额未改善');
 if(row.oi5<0||row.oi15<0)risks.push('原始Binance OI方向冲突');
 if(Math.abs(row.p5)>1.35||Math.abs(row.p15)>3.2||Math.abs(row.p24)>15||row.maxBody5>=1.35)risks.push('价格已过热');
 if(!btc||!btc.healthy||btc.shock||btc.p5<=-.65)risks.push('BTC环境不允许确认新多单');
 if(now-row.sampledAt>60_000)risks.push('Binance扫描数据过期');
 let hard=risks.some(x=>/冲突|不一致|过热|BTC|过期/.test(x));
 let state=hard?'观察·冲突':score>=75&&oi5>=.45&&oi15>=.75&&buy5>=52&&cvdProgress?'资金待验证':score>=55?'重点观察':'继续观察';
 // This is research screening, never executable trade confirmation.
 return {symbol:row.symbol,state,score,oi5,oi15,buy5,net3,netPrev,cvdProgress,volPulse,reasons,risks,when:now,
  source:'Coinalyze BINANCE USDT永续 · 已收盘5m/15m'};
}
const api={choose,mapMarkets,evaluate,change,closed};
root.FlowCore=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
