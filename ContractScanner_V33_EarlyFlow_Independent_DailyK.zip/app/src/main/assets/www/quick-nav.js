/* V32.1: result-list shortcuts. No changes to ranking, signals or API calls. */
(function(){
'use strict';
const validSymbol=s=>typeof s==='string'&&/^[A-Z0-9]{2,24}USDT$/.test(s);
function toast(message){
 const previous=document.getElementById('quickNavToast');if(previous)previous.remove();
 const el=document.createElement('div');el.id='quickNavToast';el.className='quickNavToast';el.setAttribute('role','status');el.textContent=message;
 document.body.appendChild(el);setTimeout(()=>el.remove(),2700);
}
function findCoinRow(symbol){
 const list=document.getElementById('body');if(!list)return null;
 return [...list.querySelectorAll('.coinRow')].find(el=>el.querySelector('[data-ai-symbol]')?.getAttribute('data-ai-symbol')===symbol)||null;
}
function findAndReveal(symbol){
 let row=findCoinRow(symbol);if(row)return row;
 // Only modify list filters if they currently hide this specific coin.
 const search=document.getElementById('search');
 if(search&&search.value.trim()&&!symbol.includes(search.value.trim().toUpperCase())){search.value='';search.dispatchEvent(new Event('input',{bubbles:true}));row=findCoinRow(symbol);}
 if(!row&&['ETHUSDT','BNBUSDT'].includes(symbol)&&typeof excludeMajors!=='undefined'&&excludeMajors) {document.getElementById('exclude')?.click();row=findCoinRow(symbol);}
 if(!row&&typeof leadOnly!=='undefined'&&leadOnly){document.getElementById('leadOnly')?.click();row=findCoinRow(symbol);}
 if(!row&&typeof modelFilter!=='undefined'&&modelFilter!=='all') {document.querySelector('#modelBar [data-model="all"]')?.click();row=findCoinRow(symbol);}
 return row;
}
function navigate(symbol,origin){
 if(!validSymbol(symbol))return false;
 if(typeof rows==='undefined'||!rows.some(r=>r.symbol===symbol)){
  toast(symbol+' 不在当前主列表；请先刷新原扫描器');return false;
 }
 const target=findAndReveal(symbol);
 if(!target){toast('当前筛选列表中找不到 '+symbol+'，请重新刷新');return false;}
 if(origin){const popup=origin.closest('#flowMask,#minuteMask');if(popup){popup.classList.remove('show','open');}}
 // The overlay is removed first so scrollIntoView does not scroll its own scroll container.
 requestAnimationFrame(()=>{
  const selected=findCoinRow(symbol)||target;
  selected.scrollIntoView({behavior:'smooth',block:'center'});
  selected.classList.add('quickNavTarget');
  setTimeout(()=>selected.classList.remove('quickNavTarget'),3500);
  toast('已定位 '+symbol+' · 可点击5m复查 / 结构复查 / AI分析');
 });
 return true;
}
window.ScannerQuickNav={navigate};
document.addEventListener('click',event=>{
 const el=event.target.closest('[data-quick-copy],[data-quick-binance],[data-quick-jump]');
 if(!el||!el.closest('#flowResults,#minuteList'))return;
 event.preventDefault();event.stopPropagation();
 if(el.hasAttribute('data-quick-copy')){
  const symbol=el.dataset.quickCopy;
  if(!/^[A-Z0-9]{2,24}$/.test(symbol))return;
  // Reuse the original App native clipboard + fallback, including its visual confirmation.
  if(typeof copySymbol==='function'){el.dataset.copy=symbol;copySymbol(el);}
  else if(window.ScannerNative?.copyCoinSymbol?.(symbol))toast('已复制 '+symbol);
  return;
 }
 if(el.hasAttribute('data-quick-binance')){
  const symbol=el.dataset.quickBinance;
  if(validSymbol(symbol)&&typeof openBinanceFutures==='function')openBinanceFutures(symbol);
  return;
 }
 if(el.hasAttribute('data-quick-jump'))navigate(el.dataset.quickJump,el);
});
})();
