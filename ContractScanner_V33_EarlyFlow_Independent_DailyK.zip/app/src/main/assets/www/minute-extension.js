/* V32 additive UI: ONE new 1m tab; original scanner and V31 flow plugin are unmodified. */
(function(){
'use strict';
const M=window.MinuteCore,F=window.FlowCore;
const $=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[k]));
const native=()=>window.ScannerNative;
let running=false,aiBusy=false,pendingAI='',lastStarted=0,marketCache=null,requestId=0;
let results=new Map(),calls=new Map(),lastNotified=new Map();
let settings={auto:false,notify:false};
try{let v=JSON.parse(localStorage.getItem('minuteV32Settings')||'null');if(v)settings={auto:!!v.auto,notify:!!v.notify}}catch(e){}
const save=()=>{try{localStorage.setItem('minuteV32Settings',JSON.stringify(settings))}catch(e){}};
const style=document.createElement('style');style.textContent=`
.minuteLaunch{border:1px solid #209b82;background:#10332f;color:#b4f8dd;border-radius:8px;padding:6px;font-size:11px;font-weight:800;white-space:nowrap}
.minuteMask{display:none;position:fixed;inset:0;z-index:94;background:rgba(0,7,15,.92);align-items:center;justify-content:center;padding:10px}
.minuteMask.open{display:flex}.minuteBox{width:min(720px,100%);max-height:95vh;overflow:auto;padding:14px;background:#0b1728;border:1px solid #377c75;border-radius:14px;color:#f0f7ff}
.minuteHeader{display:flex;align-items:center;justify-content:space-between;gap:7px}.minuteHeader b{font-size:16px}
.minuteBtn{border:1px solid #367b72;border-radius:8px;background:#113934;color:#d7fff1;padding:8px;font-size:12px;font-weight:bold}.minuteBtn:disabled{opacity:.55}
.minuteP{font-size:11px;line-height:1.6;color:#a6bdcc;margin:8px 0}.minuteBtns{display:flex;gap:6px;flex-wrap:wrap;margin:9px 0}
.minuteItem{border:1px solid #34516b;border-radius:10px;padding:9px;margin:9px 0;background:#122239}.minuteItem.good{border-color:#24aa7f}.minuteItem.watch{border-color:#c19541}
.minuteItemHeader{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}.minuteItem small{display:block;color:#a7c1d7;font-size:11px;line-height:1.5;margin-top:5px}
.minuteBadge{font-size:9px;line-height:1.4;white-space:nowrap;padding:2px 5px;margin-left:5px;border-radius:5px;color:#d5fff0;background:#12604c}
.coinRow.minuteStrong{border:2px solid rgba(28,202,147,.78)!important;background:rgba(30,167,123,.055)!important}
.coinRow.minuteWatch{border:1px solid rgba(222,175,79,.55)!important}
.coinFlags .minuteInline{display:inline-flex;font-size:9px;line-height:13px;background:#15483c;color:#b8fbe2;padding:1px 4px;border-radius:4px;flex:0 0 auto}
.coinFlags .minuteInline.watch{background:#51411c;color:#ffe4a3}
@media(max-width:550px){.minuteLaunch{font-size:10px;padding:5px 3px}.flowOpen{font-size:10px;padding:5px 3px}}
`;document.head.appendChild(style);
const trigger=document.createElement('button');trigger.id='minuteOpen';trigger.type='button';trigger.className='minuteLaunch';trigger.textContent='⚡ 1m资金预警';
$('flowOpen')?.insertAdjacentElement('afterend',trigger);
const modal=document.createElement('div');modal.className='minuteMask';modal.id='minuteMask';modal.innerHTML=`<section class="minuteBox" role="dialog" aria-modal="true" aria-label="Coinalyze 1分钟资金预警">
<div class="minuteHeader"><b>⚡ 1分钟资金先行动量 · V32</b><button class="minuteBtn" id="minuteClose">关闭 ×</button></div>
<p class="minuteP">双通道发现（5m OI候选 + 活跃度先行候选），每次复核最多4个币：1分钟OI、3分钟OI增速、主动买卖量差额、温和量能及BTC风控。高分只是研究预警，不表示可以买入。</p>
<div class="minuteBtns"><button class="minuteBtn" id="minuteRun">立即复核1分钟</button><button class="minuteBtn" id="minuteAI">AI复核1m前4名</button><button class="minuteBtn" id="minuteSettings">Coinalyze密钥设置</button><button class="minuteBtn" id="minuteExport">导出1m样本</button></div>
<label class="minuteP"><input type="checkbox" id="minuteAuto"> 完成原版Binance刷新后自动复核1分钟（默认关闭）</label>
<label class="minuteP"><input type="checkbox" id="minuteNotify"> 出现1m重点复核时发送系统通知（默认关闭；仅App运行时）</label>
<p class="minuteP" id="minuteKeyStatus">检查Coinalyze密钥中…</p>
<p class="minuteP" id="minuteStatus" aria-live="polite">请先点原版「刷新」，再点「立即复核1分钟」。</p>
<div id="minuteList"></div>
<p class="minuteP">1m来源为Coinalyze已完成K线；币安实时OI快照用于优先排序，不伪称为1m历史K线。1m积分仅为实验性研究量表；CVD使用主动买卖量差额代理，不是完整聚合CVD。每次最多4币×2个历史接口；原5m资金+仍可独立使用，两个增强扫描共享Coinalyze Key额度。市场突变、历史不连贯、BTC不健康会拒绝确认。</p>
</section>`;document.body.appendChild(modal);
const status=s=>$('minuteStatus').textContent=s;
const hasKey=()=>{try{return native()?.hasCoinalyzeKey?.()===true}catch(e){return false}};
function keyStatus(){$('minuteKeyStatus').textContent=hasKey()?'● 已设置Coinalyze API Key（本机加密保存）':'未设置Coinalyze API Key。点击「Coinalyze密钥设置」完成配置。'}
const show=()=>{modal.classList.add('open');keyStatus();paint()};const hide=()=>modal.classList.remove('open');
trigger.onclick=show;$('minuteClose').onclick=hide;modal.addEventListener('click',e=>{if(e.target===modal)hide()});
$('minuteSettings').onclick=()=>{$('flowOpen')?.click();hide()};
$('minuteAuto').checked=settings.auto;$('minuteNotify').checked=settings.notify;
$('minuteAuto').onchange=e=>{settings.auto=e.target.checked;save()};
$('minuteNotify').onchange=e=>{settings.notify=e.target.checked;save();if(settings.notify&&!native()?.hasNotificationPermission?.())native()?.requestNotifications?.()};
function btcSnapshot(){const r=rows.find(x=>x.symbol==='BTCUSDT');
 let d=typeof defenseStatus==='function'?defenseStatus():null;
 return {p5:(typeof btcMonitorHealthy==='function'&&btcMonitorHealthy()&&typeof btcLive!=='undefined'&&btcLive)?btcLive.p5:r?.p5,
 healthy:typeof btcMonitorHealthy==='function'&&btcMonitorHealthy(),shock:!!d?.active||!!(typeof marketRisk!=='undefined'&&marketRisk.needsRescan)};
}
function dispatchApi(path,params){return new Promise((resolve,reject)=>{
 if(!native()?.coinalyzeGet){reject(Error('只支持新版Android APK原生接口'));return}
 const id='minute-'+Date.now()+'-'+(++requestId);
 const timer=setTimeout(()=>{calls.delete(id);reject(Error('接口超时'))},26000);
 calls.set(id,{resolve,reject,timer});
 try{native().coinalyzeGet(id,path,JSON.stringify(params))}catch(e){clearTimeout(timer);calls.delete(id);reject(e)}
})}
window.__minuteApiResult=(id,ok,payload)=>{const item=calls.get(id);if(!item)return;
 clearTimeout(item.timer);calls.delete(id);if(!ok){item.reject(Error(String(payload||'接口请求失败')));return}
 try{item.resolve(JSON.parse(payload))}catch(e){item.reject(Error('Coinalyze返回的JSON不可解析'))}};
async function markets(){if(marketCache&&Date.now()-marketCache.when<20*3600000)return marketCache.items;
 let x=await dispatchApi('future-markets',{});if(!Array.isArray(x))throw Error('Coinalyze市场格式不正确');
 marketCache={when:Date.now(),items:x};return x;
}
function histFor(data,sym){if(!Array.isArray(data))throw Error('Coinalyze历史格式不正确');let e=data.find(x=>x?.symbol===sym);if(!e||!Array.isArray(e.history))throw Error('缺少对应永续市场的历史');return e.history}
function rowFor(r){const kind=r.state==='1m重点复核'?'good':r.state==='1m继续观察'?'watch':'';
 const age=Date.now()-r.when,old=age>60000;
 const measures=Number.isFinite(r.score)?`1m OI ${r.oi1.toFixed(2)}% · 3m OI ${r.oi3.toFixed(2)}% · 3m主动买入 ${r.buy3.toFixed(1)}% · 3m价格 ${r.p3.toFixed(2)}% · 量能 ${r.volumePulse.toFixed(2)}倍`:'';
 return `<div class="minuteItem ${old?'':kind}"><div class="minuteItemHeader"><button type="button" class="quickCoinCopy" data-quick-copy="${esc(r.symbol.replace(/USDT$/,''))}" title="点币名复制（和主列表一致）">${esc(r.symbol)}</button><b>${Number.isFinite(r.score)?r.score+'/100':'—'} · ${old?'数据已过期':esc(r.state)}</b></div>
 <div class="quickResultActions"><button type="button" data-quick-binance="${esc(r.symbol)}" title="启动手机币安官方App（不自动下单）">B↗ 币安App</button><button type="button" class="quickJump" data-quick-jump="${esc(r.symbol)}" title="回到主列表本币，使用5m复查、结构复查和AI分析">↩ 返回本币 · 复查 / AI</button></div>
 <small>${esc(measures)}</small><small>${esc((r.reasons||[]).join('；'))}</small><small>${esc((r.risks||[]).length?'风险：'+r.risks.join('；'):'')}</small>
 ${r.ai?`<small>🤖 ${esc(r.ai.action)}：${esc(r.ai.summary)}；${esc((r.ai.risks||[]).join('；'))}</small>`:''}</div>`;
}
function paint(){const values=[...results.values()].sort((a,b)=>(b.score??-1)-(a.score??-1));$('minuteList').innerHTML=values.length?values.map(rowFor).join(''):'<p class="minuteP">暂无1分钟资金结果。</p>';flags()}
function flags(){const container=$('body');if(!container)return;
 container.querySelectorAll('.coinRow').forEach(el=>{
  el.classList.remove('minuteStrong','minuteWatch');el.querySelectorAll('.minuteInline').forEach(e=>e.remove());
  let sym=el.querySelector('[data-ai-symbol]')?.getAttribute('data-ai-symbol'),r=results.get(sym);
  if(!r||!Number.isFinite(r.score)||Date.now()-r.when>60000)return;
  let good=r.state==='1m重点复核',watch=r.state==='1m继续观察';
  if(!good&&!watch)return;
  el.classList.add(good?'minuteStrong':'minuteWatch');
  const holder=el.querySelector('.coinFlags');if(holder){let b=document.createElement('span');b.className='minuteInline'+(watch?' watch':'');b.textContent=(good?'⚡1m重点 ':'1m观察 ')+r.score;holder.appendChild(b)}
 })}
const list=$('body');if(list)new MutationObserver(()=>flags()).observe(list,{childList:true});
function maybeNotify(r){if(!settings.notify||r.state!=='1m重点复核'||!native()?.notifyRisk)return;
 let old=lastNotified.get(r.symbol)||0;if(Date.now()-old<10*60000)return;
 lastNotified.set(r.symbol,Date.now());try{native().notifyRisk('1分钟资金研究预警 · '+r.symbol,'OI '+r.oi3.toFixed(2)+'%，主动买入 '+r.buy3.toFixed(1)+'%，请人工复核；非入场信号')}catch(e){}
}
async function scan(silent=false){if(running)return;
 if(!hasKey()){if(!silent)show();status('请先在资金+筛选中保存Coinalyze API Key');return}
 if(Date.now()-lastStarted<70000){if(!silent)show();status('1分钟接口冷却中：距上次请求不足70秒');return}
 if(typeof scanning!=='undefined'&&scanning){if(!silent)show();status('原版Binance扫描尚未完成');return}
 let selected=window.ScannerEngineV33.selectMinute(rows,Date.now());if(!selected.length){results.clear();paint();if(!silent)show();status('当前没有值得交易的候选，继续等待。请确认原版扫描已完成且快照未过期');return}
 running=true;lastStarted=Date.now();$('minuteRun').disabled=true;results.clear();paint();if(!silent)show();
 try{
  status('核对Coinalyze币安永续交易对…');let marketList=await markets();
  let matching=selected.map(x=>({...x,coinalyze:F.mapMarkets(marketList,x.row.symbol)})).filter(x=>x.coinalyze);
  if(!matching.length)throw Error('无币安USDT永续交易对，禁止使用其他交易所OI替代');
  const end=Math.floor(Date.now()/1000),from=end-30*60, symbols=matching.map(x=>x.coinalyze).join(',');
  status('正在查询 '+matching.length+' 个币的1m OI + 主动成交…');
  const [oi,vol]=await Promise.all([
   dispatchApi('open-interest-history',{symbols,interval:'1min',from,to:end}),
   dispatchApi('ohlcv-history',{symbols,interval:'1min',from,to:end})
  ]);
  let count=0;for(let item of matching){try{
   let r=M.evaluate(item.row,histFor(oi,item.coinalyze),histFor(vol,item.coinalyze),btcSnapshot(),Date.now());
   results.set(r.symbol,r);maybeNotify(r);
  }catch(e){results.set(item.row.symbol,{symbol:item.row.symbol,score:null,state:'接口数据不足',reasons:[],risks:[String(e.message||e)],when:Date.now()})}count++}
  paint();let alert=[...results.values()].filter(x=>x.state==='1m重点复核').length;
  status(alert?`复核完成 ${count} 个；${alert} 个符合1m研究预警。请继续核对5m/15m和BTC，不可直接入场。`:
    `复核完成 ${count} 个；当前没有符合严格1m条件的候选，继续等待。`);
 }catch(e){status('1分钟复核未完成：'+String(e.message||e).slice(0,180)+'。原版功能正常运行');}
 finally{running=false;$('minuteRun').disabled=false}
}
$('minuteRun').onclick=()=>scan(false);
window.__minuteAIResponse=(id,ok,payload)=>{
 if(id!==pendingAI)return;pendingAI='';aiBusy=false;$('minuteAI').disabled=false;
 if(!ok){status('1m AI复核失败：'+String(payload).slice(0,180));return}
 try{let data=JSON.parse(payload);if(!Array.isArray(data.results))throw Error('AI返回格式缺少results');
  for(let x of data.results){let r=results.get(x.symbol);if(!r)continue;r.ai={action:String(x.action||'继续观察').slice(0,40),summary:String(x.summary||'').slice(0,250),risks:Array.isArray(x.risks)?x.risks.slice(0,5):[]}}
  paint();status('AI已完成独立风险复核。结论仅供人工检查，不构成下单指令。');
 }catch(e){status('1m AI回复格式错误：'+e.message)}
};
$('minuteAI').onclick=()=>{
 if(aiBusy)return;if(!native()?.hasOpenAIKey?.()){show();status('先到原「AI设置」保存OpenAI API Key');return}
 const a=[...results.values()].filter(x=>Number.isFinite(x.score)&&Date.now()-x.when<=60000).sort((a,b)=>b.score-a.score).slice(0,4);
 if(!a.length){status('先重新运行1m资金复核；超出60秒的数据不提供给AI');return}
 const btc=btcSnapshot();const input={task:'1m OI + active buyer/seller imbalance early warning with 5m and 15m Binance cross-check',
 disclaimer:'仅使用已收盘1m数据；研究评分未经校准，OI不表示方向，主动成交差额是CVD代理；不能自动交易',
 btc,symbols:a.map(x=>({symbol:x.symbol,score:x.score,state:x.state,coinalyze1m:{oi1:x.oi1,oi3:x.oi3,prevOi3:x.prevOi3,p1:x.p1,p3:x.p3,buy3:x.buy3,net3:x.net3,prevNet3:x.prevNet3,volumePulse:x.volumePulse,candleCloseAt:x.candleCloseAt},
  binance:(()=>{let r=rows.find(y=>y.symbol===x.symbol);return r?{p5:r.p5,p15:r.p15,p24:r.p24,oi5:r.oi5,oi15:r.oi15,buy5:r.buy5,cvd5:r.cvd5,oiUsd:r.oiUsd}:null})(),reasons:x.reasons,risks:x.risks}))};
 aiBusy=true;let id='minuteAI-'+Date.now();pendingAI=id;$('minuteAI').disabled=true;status('AI分析1m资金预警与5m/15m结构冲突…');
 try{native().reviewMinuteAI(id,JSON.stringify(input),$('aiModel')?.value||'gpt-4.1-mini')}catch(e){window.__minuteAIResponse(id,false,String(e))}
};
$('minuteExport').onclick=()=>{
 const data={schema:'contractScannerMinuteV32',exportedAt:new Date().toISOString(),scoreNotProbability:true,results:[...results.values()]};
 if(typeof saveScannerJson==='function')saveScannerJson('FlowPlusV32_1m_'+Date.now()+'.json',data);
 else status('当前环境不支持导出');
};
// Extend the refresh click only; do not modify Binance scan itself, rows or original signals.
const earlier=$('refresh')?.onclick;
if(typeof earlier==='function')$('refresh').onclick=async function(){await earlier.apply(this,arguments);if(settings.auto&&!running)await scan(true)};
const closePrior=window.scannerCloseOverlay;
window.scannerCloseOverlay=()=>{if(modal.classList.contains('open')){hide();return true}return typeof closePrior==='function'?closePrior():false};
})();
