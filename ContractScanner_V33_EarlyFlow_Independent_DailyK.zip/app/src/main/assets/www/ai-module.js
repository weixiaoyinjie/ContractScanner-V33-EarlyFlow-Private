/* Contract Scanner: optional read-only per-coin OpenAI research extension. */
(function(){
'use strict';
const native = () => window.ScannerNative;
const modes=['综合复核','启动结构','OI资金','风险排雷'];
const $ai=id=>document.getElementById(id);
const escaped=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const validPair=s=>/^[A-Z0-9]{2,24}USDT$/.test(s);
const vals=(a,max)=>Array.isArray(a)?a.slice(-max).map(x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x))?Number(Number(x).toFixed(4)):null):[];
let symbol='',mode=modes[0],requestNum=0,inflight='',inflightFor=null,historyCache=new Map();
const results=new Map();
const keyOf=(s,m)=>s+'_'+m;
const panel=document.createElement('div');
panel.innerHTML=`
<div class="aiMask" id="aiSettingsMask" role="dialog" aria-label="OpenAI设置" aria-modal="true">
 <div class="aiShell"><div class="aiHead"><strong>🤖 OpenAI API 设置</strong><button id="aiSettingsClose">关闭 ×</button></div>
 <p class="aiMuted">仅手动点击币种 AI分析时调用。与原扫描规则分离，不修改原指标、筛选、统计或复查。</p>
 <label>OpenAI 平台 API Key（加密保存在 Android Keystore）</label>
 <input class="aiSettingInput" type="password" id="aiKey" autocomplete="off" placeholder="sk-..." />
 <div class="aiRowBtns"><button class="aiSettingBtn" id="aiSaveKey">加密保存 Key</button><button class="aiSettingBtn" id="aiDeleteKey">删除 Key</button></div>
 <div class="aiMuted" id="aiKeyStatus">检测本机密钥…</div>
 <label>分析模型</label><select id="aiModel" class="aiSelect"><option value="gpt-4.1-mini">gpt-4.1-mini（默认）</option><option value="gpt-4o-mini">gpt-4o-mini（经济）</option></select>
 <p class="aiMuted">OpenAI API 调用按平台 API 账户独立计费，ChatGPT 订阅不包含 API 用量。密钥仅发送至 api.openai.com，不传给 Binance；本 App 不下单、不读取你的交易账户。</p>
 </div>
</div>
<div class="aiMask" id="aiReviewMask" role="dialog" aria-label="币种AI多维交叉复核" aria-modal="true">
 <div class="aiShell"><div class="aiHead"><strong id="aiTitle">AI 多维复核 · 非交易指令</strong><button id="aiClose">关闭 ×</button></div>
 <div class="aiMuted" id="aiContext">尚未选择币种</div>
 <div class="aiTabs" id="aiTabs">${modes.map((x,i)=>`<button type="button" data-ai-mode="${x}" class="${i===0?'active':''}">${x}</button>`).join('')}</div>
 <button class="aiAction" type="button" id="aiDoReview">获取最新数据并执行 AI 复核</button>
 <p class="aiMuted">每点击一个模式，单独请求一次 AI；仅使用该币种最新快照与可读取的历史数据。OI为交易所快照，CVD为K线成交主动量代理，不可当作完整逐笔CVD。</p>
 <div class="aiBox" id="aiOutput" aria-live="polite">等待手动复核。结构、资金、风险四种模式可分别分析；数据不足时应为 C/PASS，AI等级不是回测胜率。</div>
 </div>
</div>`;
document.body.append(...panel.children);
const cfg=$ai('aiSettingsMask'),mask=$ai('aiReviewMask');
const close=el=>el.classList.remove('show');
const show=el=>el.classList.add('show');
function showConfig(){show(cfg);try{$ai('aiKeyStatus').textContent=native()?.hasOpenAIKey()?'本机已保存加密 Key':'未设置 Key；先保存后才能复核';}catch(e){$ai('aiKeyStatus').textContent='仅支持 Android 安装版保存 Key';}}
function showCoin(s){if(!validPair(s))return;symbol=s;mode=modes[0];show(mask);$ai('aiTitle').textContent=s.replace(/USDT$/,'')+' · AI 多维分析';updateTabs();refreshSummary();}
function updateTabs(){document.querySelectorAll('#aiTabs [data-ai-mode]').forEach(b=>b.classList.toggle('active',b.dataset.aiMode===mode));}
function refreshSummary(){let row=typeof rows!=='undefined'?rows.find(r=>r.symbol===symbol):null;const valid=row&&typeof rowIsFresh==='function'&&rowIsFresh(row);$ai('aiContext').textContent=(valid?'● 行情≤60秒':'⚠ 行情过期或尚未扫描')+' · '+symbol+' · '+mode+' · 评级不是实际胜率';let saved=results.get(keyOf(symbol,mode));if(saved&&Date.now()-saved.when<5*60_000){showResult(saved.data,saved.when,true);}else{$ai('aiOutput').textContent=valid?'点击下方按钮，人工触发当前币的独立复核。':'请先刷新扫描数据，再执行 AI 复核。';}}
function showResult(data,at,cached){const root=$ai('aiOutput');root.replaceChildren();const cleanGrade=['A','B','C','PASS'].includes(data.grade)?data.grade:'PASS';const grade=document.createElement('div');grade.className='aiGrade '+(cleanGrade==='A'?'good':cleanGrade==='B'?'wait':'pass');grade.textContent=`${cleanGrade}级 · ${data.bias||'观望'} · ${data.action||'继续观察'}`;root.appendChild(grade);const info=document.createElement('div');info.className='aiMuted';info.textContent=(cached?'缓存结果 · ':'')+new Date(at).toLocaleTimeString()+' · '+mode+' · 不代表胜率或自动入场';root.appendChild(info);const summary=document.createElement('div');summary.textContent=data.summary||'未返回分析摘要';root.appendChild(summary);
 for(const [name,val] of [['核心证据',data.evidence],['风险与冲突',data.risks],['仍缺少的数据',data.missingData],['需要确认的条件',data.conditions]]){
  const title=document.createElement('p');title.style.fontWeight='800';title.style.margin='10px 0 5px';title.textContent=name;root.appendChild(title);
  const arr=Array.isArray(val)?val:[];if(!arr.length){const x=document.createElement('div');x.className='aiMuted';x.textContent='未列出';root.appendChild(x);}
  for(const point of arr.slice(0,6)){const x=document.createElement('div');x.className='aiPoint';x.textContent=String(point).slice(0,300);root.appendChild(x);}
 }
}
function safeNumber(x){return Number.isFinite(x)?Number(x.toFixed(6)):null}
function buildBase(row){const now=Date.now(),btc=rows.find(r=>r.symbol==='BTCUSDT'),pf=pre15Filter(row),pr=priorityClassify(row),classification=classify(row),defense=defenseStatus();let continuation=null;try{continuation=continuationCheck(row)}catch(e){}
const numericKeys=['cur','p1','p5','p15','p24','p1h','p2h','p4h','oi5','oi15','oiUsd','cvd5','buy5','buy15','volPulse5','medianRange5','maxRange5','rise20','maxBull15','net4','net6','hh','hl','drives','p2m'];
const metrics={};for(const k of numericKeys){let v=row[k];metrics[k]=typeof v==='number'&&Number.isFinite(v)?safeNumber(v):null;}
return {symbol:row.symbol,analysisMode:mode,market:'Binance USDT永续',requestTime:new Date(now).toISOString(),snapshotAgeSeconds:Number.isFinite(row.sampledAt)?Math.round((now-row.sampledAt)/1000):null,metrics, oi_note:'持仓量历史快照，不是逐笔实时OI',cvd_note:'CVD动能为K线主动买卖成交额代理，不是完整逐笔CVD',rule:{raw:classification.kind,priority:pr.kind,priorityLabel:pr.label||null,pre15:{blocked:pf.block,kind:pf.kind,reason:pf.reason||null},oiLead:oiLead(row),continuationPass:continuation?.pass??null},btc:{snapshot:btc?{p1:btc.p1,p5:btc.p5,p15:btc.p15,oi5:btc.oi5,buy5:btc.buy5,cvd5:btc.cvd5}:null,healthy:btcMonitorHealthy(),bias:btcBias(),emergencyDefense:!!defense.active,needsRescan:!!marketRisk.needsRescan}};
}
const mean=a=>a.length?a.reduce((t,x)=>t+x,0)/a.length:null;
async function enrich(snapshot){
const s=snapshot.symbol;const key=s;let hit=historyCache.get(key);if(hit&&Date.now()-hit.when<25000){snapshot.history=hit.data;return snapshot}
try{
 const d=await reviewDetail(s);const candle=k=>({ts:Number(k[0]),close:Number(k[4]),quoteVolume:Number(k[7]),buyRatio:Number(k[7])>0?Number((100*Number(k[10])/Number(k[7])).toFixed(1)):null,high:Number(k[2]),low:Number(k[3])});
 const recent5=d.k5.filter(k=>Number(k[6])<=Date.now()).slice(-10).map(candle);
 const recent15=d.k15.filter(k=>Number(k[6])<=Date.now()).slice(-8).map(candle);
 const seq5=vals(d.oi5,8),seq15=vals(d.oi15,6);
 const change=(arr)=>arr.length>=2&&arr[0]>0?safeNumber(100*(arr[arr.length-1]/arr[0]-1)):null;
 snapshot.history={updatedAt:new Date(d.ts).toISOString(),kline5m:recent5,kline15m:recent15,oi5mValues:seq5,oi15mValues:seq15,oi5mWindowPct:change(seq5),oi15mWindowPct:change(seq15),cvdProxySequence:vals(d.cvd,8),flow5mLast8:d.flow.slice(-8).map(a=>({buy:Math.round(a.buy),sell:Math.round(a.sell)})),dataSource:'Binance Futures Kline & openInterestHist'};
 historyCache.set(key,{when:Date.now(),data:snapshot.history});
}catch(err){snapshot.history={unavailable:true,reason:'历史K线/OI请求失败或限流，不可补造历史数据'};}
return snapshot;
}
function handleResponse(id,ok,payload){if(id!==inflight)return;const scope=inflightFor;inflightFor=null;inflight='';$ai('aiDoReview').disabled=false;$ai('aiDoReview').textContent='获取最新数据并执行 AI 复核';if(!ok){if(scope&&symbol===scope.symbol&&mode===scope.mode)$ai('aiOutput').textContent='AI 请求失败：'+String(payload).slice(0,260);return}
 try{const data=JSON.parse(payload);if(!data||!['A','B','C','PASS'].includes(data.grade))throw Error('AI 返回评级无效');results.set(keyOf(scope.symbol,scope.mode),{data,when:Date.now()});if(symbol===scope.symbol&&mode===scope.mode)showResult(data,Date.now(),false)}catch(err){$ai('aiOutput').textContent='接口返回格式不完整：'+(err.message||err)}}
window.__scannerAIResponse=handleResponse;
async function submit(){if(inflight){$ai('aiOutput').textContent='已有一项 AI 请求处理中，请等待完成。';return}
if(!native()||typeof native().reviewCoinAI!=='function'){$ai('aiOutput').textContent='AI 调用需要安装 APK 后在安卓手机上使用。';return}
let keySet=false;try{keySet=native().hasOpenAIKey()}catch(e){}if(!keySet){showConfig();$ai('aiOutput').textContent='请先到 AI设置 保存 OpenAI API Key';return}
const row=rows.find(r=>r.symbol===symbol);if(!row||!rowIsFresh(row)){$ai('aiOutput').textContent='本币行情已过60秒，请先刷新原扫描器后再复核。';return}
$ai('aiDoReview').disabled=true;$ai('aiDoReview').textContent='获取 Binance 历史数据 / AI 请求中…';$ai('aiOutput').textContent='正在读取该币的5m/15m K线和OI历史，再交叉复核…';const sentSymbol=symbol,sentMode=mode;
try{const snapshot=await enrich(buildBase(row));if(symbol!==sentSymbol||mode!==sentMode){$ai('aiOutput').textContent='币种或模式已切换；请重新点击分析。';return;}if(Date.now()-new Date(snapshot.requestTime).getTime()>90_000){$ai('aiOutput').textContent='历史数据读取耗时过长，请先刷新扫描。';return;}
const id='r'+Date.now()+'_'+(++requestNum);inflight=id;inflightFor={symbol:sentSymbol,mode:sentMode};native().reviewCoinAI(id,JSON.stringify(snapshot),$ai('aiModel').value);
}catch(e){$ai('aiOutput').textContent='数据准备异常：'+String(e.message||e);}finally{if(!inflight){$ai('aiDoReview').disabled=false;$ai('aiDoReview').textContent='获取最新数据并执行 AI 复核'}}}
$ai('aiSettingsOpen').onclick=showConfig;$ai('aiSettingsClose').onclick=()=>close(cfg);$ai('aiClose').onclick=()=>close(mask);
cfg.addEventListener('click',e=>{if(e.target===cfg)close(cfg)});mask.addEventListener('click',e=>{if(e.target===mask)close(mask)});
document.addEventListener('click',e=>{const b=e.target.closest('[data-ai-symbol]');if(b){e.preventDefault();e.stopPropagation();showCoin(b.dataset.aiSymbol)}},{capture:true});
$ai('aiTabs').addEventListener('click',e=>{const b=e.target.closest('[data-ai-mode]');if(!b)return;mode=b.dataset.aiMode;updateTabs();refreshSummary()});
$ai('aiDoReview').onclick=submit;
$ai('aiSaveKey').onclick=()=>{let val=$ai('aiKey').value.trim();if(!native()||!native().saveOpenAIKey){$ai('aiKeyStatus').textContent='需要 Android 安装版';return}try{const result=native().saveOpenAIKey(val);$ai('aiKeyStatus').textContent=result==='OK'?'密钥已加密保存在本机':result;if(result==='OK')$ai('aiKey').value=''}catch(e){$ai('aiKeyStatus').textContent='保存失败，请检查安卓系统的设备锁与密钥存储'}};
$ai('aiDeleteKey').onclick=()=>{if(!native()?.deleteOpenAIKey){return}native().deleteOpenAIKey();$ai('aiKey').value='';$ai('aiKeyStatus').textContent='已清除本机保存的 API Key'};
try{$ai('aiModel').value=localStorage.getItem('contractScannerAIModel')||'gpt-4.1-mini'}catch(e){}
$ai('aiModel').onchange=()=>{try{localStorage.setItem('contractScannerAIModel',$ai('aiModel').value)}catch(e){}};
document.addEventListener('keydown',e=>{if(e.key==='Escape'){close(cfg);close(mask)}});
// Existing back behavior is retained by adding a non-invasive overlay adapter.
const priorClose=window.scannerCloseOverlay;window.scannerCloseOverlay=function(){if(cfg.classList.contains('show')){close(cfg);return true}if(mask.classList.contains('show')){close(mask);return true}return typeof priorClose==='function'?priorClose():false};
})();
