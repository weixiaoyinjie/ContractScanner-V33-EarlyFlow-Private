/* FlowPlus V32 retained 5m plugin: the V30.2 UI, model statistics, risk controls, charts and old scan are untouched. */
(function(){
'use strict';
const F=window.FlowCore;
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const native=()=>window.ScannerNative;
let saved={auto:false}, running=false, busyAI=false, marketCache=null, scoreMap=new Map(), lastStarted=0, reqSerial=0;
const pending=new Map();
try{const v=JSON.parse(localStorage.getItem('flowPlusSettingsV32')||'null');if(v&&typeof v.auto==='boolean')saved.auto=v.auto;}catch(e){}
const css=document.createElement('style');css.textContent=`
.flowOpen{border:1px solid #365979;background:#112a42;color:#b5e1ff;border-radius:8px;padding:6px;font-size:11px;font-weight:800;white-space:nowrap}
.flowMask{display:none;position:fixed;inset:0;z-index:92;padding:12px;background:rgba(0,6,14,.89);align-items:center;justify-content:center}
.flowMask.show{display:flex}.flowShell{width:min(720px,100%);max-height:94vh;overflow-y:auto;border-radius:14px;border:1px solid #38516d;background:#0b1728;padding:13px;color:#edf5ff}
.flowHead{display:flex;align-items:center;justify-content:space-between;gap:8px}.flowHead strong{font-size:17px}.flowHead button,.flowBtn{background:#12304b;border:1px solid #42607e;color:#e5f3ff;border-radius:8px;padding:8px;font-weight:750;font-size:12px}
.flowSettings{display:flex;gap:7px;flex-wrap:wrap;margin:10px 0}.flowSettings input{background:#08111e;color:#fff;border:1px solid #42607e;border-radius:8px;padding:8px;min-width:100px;flex:1}
.flowTiny{font-size:11px;color:#9cb1cb;line-height:1.55;margin:7px 0}.flowLabel{font-size:11px;color:#b0c7e2;font-weight:700}.flowLine{display:flex;gap:8px;align-items:center;margin:7px 0}
.flowResult{border:1px solid #2c415b;border-radius:10px;padding:9px;margin-top:8px;background:#102036}.flowResult.good{border-color:#23a475}.flowResult.warn{border-color:#b7934a}.flowResult.bad{border-color:#a24c57}
.flowRow{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap}.flowResult strong{font-size:14px}.flowScore{font-weight:900;color:#b8e5ff}.flowReason{font-size:10px;color:#aec1da;line-height:1.5;margin-top:6px}
.flowTag{display:inline-block;font-size:8px;border-radius:4px;background:#204b4a;color:#adf3cb;padding:1px 4px;margin-left:3px}.flowTag.watch{background:#4b3a24;color:#ffe0a1}
/* Quick actions shared by the 5m Coinalyze and 1m result lists. */
.quickCoinCopy{display:inline-flex;gap:5px;align-items:center;padding:3px 2px;border:0;border-bottom:1px dashed #64a4e0;color:#f0f6ff;background:transparent;font-size:14px;font-weight:900;cursor:pointer}
.quickCoinCopy:active{opacity:.65}
.quickResultActions{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}
.quickResultActions button{border:1px solid #426684;border-radius:8px;background:#17344b;color:#deefff;padding:7px 9px;font-size:11px;font-weight:800;cursor:pointer}
.quickResultActions .quickJump{border-color:#329477;background:#12392f;color:#bff4df;flex:1}
.coinRow.quickNavTarget{outline:3px solid #64e7bd!important;outline-offset:-3px!important;box-shadow:0 0 14px rgba(52,220,161,.30)!important}
.quickNavToast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);max-width:90vw;background:#123c34;color:#e8fff5;border:1px solid #42bc90;border-radius:9px;z-index:90;padding:9px 13px;box-shadow:0 6px 25px #0008;font-size:12px;font-weight:bold;text-align:center;pointer-events:none}
.coinRow.flowHighlight{box-shadow:inset 4px 0 #3acfa2!important;border:1px solid rgba(58,207,162,.65)}.coinRow.flowCaution{border:1px solid rgba(215,155,73,.45)}
`;document.head.appendChild(css);
const trigger=document.createElement('button');trigger.className='flowOpen';trigger.textContent='资金+筛选';trigger.type='button';trigger.id='flowOpen';
const title=document.querySelector('.top .title');const aiSettings=$('aiSettingsOpen');if(aiSettings)aiSettings.insertAdjacentElement('afterend',trigger);else title?.appendChild(trigger);
const overlay=document.createElement('div');overlay.id='flowMask';overlay.className='flowMask';overlay.innerHTML=`<section class="flowShell" role="dialog" aria-modal="true" aria-label="Coinalyze+AI资金筛选">
<div class="flowHead"><strong>资金先行 · Coinalyze + AI</strong><button type="button" id="flowClose">关闭 ×</button></div>
<p class="flowTiny">原来的5m排序、双模型、图表、BTC防御、复查与仓位工具全部保留。这里是额外研究层，不直接改变原有入场判定。所有资金分数均为未校准的筛选指标，不是胜率。</p>
<div class="flowLabel">Coinalyze API Key（Android Keystore本机加密）</div>
<div class="flowSettings"><input type="password" id="flowKey" placeholder="输入Coinalyze API Key" autocomplete="off"><button class="flowBtn" id="flowSaveKey">保存</button><button class="flowBtn" id="flowDeleteKey">清除</button></div>
<div class="flowTiny" id="flowKeyStatus">检测密钥…</div>
<div class="flowLine"><label class="flowTiny"><input type="checkbox" id="flowAuto"> 完成原版Binance刷新后自动补充资金筛选（每70秒最多一次）</label></div>
<div class="flowSettings"><button class="flowBtn" id="flowStart">Coinalyze资金筛选</button><button class="flowBtn" id="flowAI">AI批量复核前5名</button><button class="flowBtn" id="flowExport">导出研究结果</button></div>
<div class="flowTiny" id="flowStatus" aria-live="polite">先运行原扫描器，选择近60秒候选，再核查Coinalyze 5m/15m OI和主动买卖结构。</div>
<div id="flowResults"></div>
<p class="flowTiny">最多核查8个币，每币查询3类历史数据；Coinalyze按币种计费的API额度约40次/分钟。AI仅手动触发，消耗OpenAI API额度。数据缺失、BTC急变或方向冲突均不能判定为确认入场。不开启API时，旧功能照常运行。</p>
</section>`;document.body.appendChild(overlay);
const show=()=>{overlay.classList.add('show');updateKeyLabel();draw()};const hide=()=>overlay.classList.remove('show');
trigger.onclick=show;$('flowClose').onclick=hide;overlay.addEventListener('click',e=>{if(e.target===overlay)hide()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay.classList.contains('show'))hide()});
$('flowAuto').checked=saved.auto;$('flowAuto').onchange=e=>{saved.auto=e.target.checked;try{localStorage.setItem('flowPlusSettingsV32',JSON.stringify(saved))}catch(e){}};
function updateKeyLabel(){try{$('flowKeyStatus').textContent=native()?.hasCoinalyzeKey()?'● 已加密保存Coinalyze密钥':'尚未设置Coinalyze密钥';}catch(e){$('flowKeyStatus').textContent='请在Android APK中保存API密钥';}}
$('flowSaveKey').onclick=()=>{let key=$('flowKey').value.trim();if(!native()?.saveCoinalyzeKey){$('flowKeyStatus').textContent='需在新版Android APK中使用';return}
 try{let res=native().saveCoinalyzeKey(key);$('flowKeyStatus').textContent=res==='OK'?'● 密钥已加密保存':res;if(res==='OK')$('flowKey').value='';}catch(e){$('flowKeyStatus').textContent='密钥保存失败：'+e.message}};
$('flowDeleteKey').onclick=()=>{try{native()?.deleteCoinalyzeKey();$('flowKey').value='';updateKeyLabel()}catch(e){}};
function status(s){$('flowStatus').textContent=s}
function callAPI(path,params){return new Promise((resolve,reject)=>{
 if(!native()?.coinalyzeGet){reject(Error('需要新版Android APK原生接口'));return}
 let id='f'+Date.now()+'_'+(++reqSerial),timeout=setTimeout(()=>{pending.delete(id);reject(Error('请求超时'))},25000);
 pending.set(id,{resolve,reject,timeout});native().coinalyzeGet(id,path,JSON.stringify(params));
})}
window.__flowApiResult=function(id,ok,payload){let p=pending.get(id);if(!p)return;clearTimeout(p.timeout);pending.delete(id);
 if(!ok){p.reject(Error(String(payload||'接口失败').slice(0,160)));return}
 try{p.resolve(JSON.parse(payload))}catch(e){p.reject(Error('Coinalyze JSON解析失败'))}
};
function canResearch(){return native()?.hasCoinalyzeKey?.()===true}
function btcState(){let r=rows.find(x=>x.symbol==='BTCUSDT');let defense=typeof defenseStatus==='function'&&defenseStatus();let healthy=typeof btcMonitorHealthy==='function'&&btcMonitorHealthy();return {p5:r?.p5??null,healthy:!!healthy,shock:!!defense?.active||!!(typeof marketRisk!=='undefined'&&marketRisk.needsRescan)};}
function rowMarkup(r){let good=r.state==='资金待验证',warn=r.state==='重点观察',has=r.score!==null;
 const stale=Date.now()-r.when>60000;return `<article class="flowResult ${good&&!stale?'good':warn&&!stale?'warn':!has?'bad':''}">
 <div class="flowRow"><button type="button" class="quickCoinCopy" data-quick-copy="${esc(r.symbol.replace(/USDT$/,''))}" title="点币名复制（和主列表一致）">${esc(r.symbol)} ${good?'🟢':warn?'🟡':''}</button><span class="flowScore">${has?r.score+'/100':'—'} · ${stale?'历史快照已过期':esc(r.state)}</span></div>
 <div class="quickResultActions"><button type="button" data-quick-binance="${esc(r.symbol)}" title="启动手机币安官方App（不自动下单）">B↗ 币安App</button><button type="button" class="quickJump" data-quick-jump="${esc(r.symbol)}" title="回到主列表此币的位置，使用5m复查、结构复查和AI分析">↩ 返回本币 · 复查 / AI</button></div>
 <div class="flowReason">${(r.reasons||[]).map(esc).join('；')||'没有满足完整确认条件'}。${(r.risks||[]).length?' 风险：'+r.risks.map(esc).join('；'):''}</div>
 ${r.ai?`<div class="flowReason">🤖 AI核查：${esc(r.ai.action)} · ${esc(r.ai.summary)} · ${esc((r.ai.risks||[]).join('；'))}</div>`:''}
 </article>`;}
function draw(){let a=[...scoreMap.values()].sort((a,b)=>(b.score??-1)-(a.score??-1));$('flowResults').innerHTML=a.length?a.map(rowMarkup).join(''):'<div class="flowTiny">尚无增强数据。请先使用原版刷新，再点击资金筛选。</div>'}
function flags(){let list=$('body');if(!list)return;list.querySelectorAll('.coinRow').forEach(el=>{el.classList.remove('flowHighlight','flowCaution');el.querySelectorAll('.flowTag').forEach(x=>x.remove());
 let symbol=el.querySelector('[data-ai-symbol]')?.getAttribute('data-ai-symbol');let r=scoreMap.get(symbol),base=rows.find(x=>x.symbol===symbol);if(!r||!Number.isFinite(r.score)||Date.now()-r.when>60000||!base||base.sampledAt>r.when)return;
 if(r.state==='资金待验证')el.classList.add('flowHighlight');else if(r.state==='重点观察')el.classList.add('flowCaution');
 let target=el.querySelector('.coinFlags');if(target){let tag=document.createElement('span');tag.className='flowTag'+(r.state==='资金待验证'?'':' watch');tag.textContent='资金 '+r.score+' · '+r.state;target.appendChild(tag)}
});}
const list=$('body');if(list)new MutationObserver(()=>flags()).observe(list,{childList:true});
async function loadMarkets(){if(marketCache&&Date.now()-marketCache.when<24*3600_000)return marketCache.data;
 const ms=await callAPI('future-markets',{});if(!Array.isArray(ms))throw Error('市场列表格式异常');marketCache={when:Date.now(),data:ms};return ms}
async function fetchOne(candidate,market){let r=candidate.row;let end=Math.floor(Date.now()/1000);let from=end-4*3600;
 // All three calls count independently toward the published symbol-based quota.
 let [oi5,oi15,v5]=await Promise.all([
 callAPI('open-interest-history',{symbols:market,interval:'5min',from,to:end}),
 callAPI('open-interest-history',{symbols:market,interval:'15min',from,to:end}),
 callAPI('ohlcv-history',{symbols:market,interval:'5min',from,to:end})]);
 const h=(res)=>{if(!Array.isArray(res))throw Error('Coinalyze数据返回不是数组');let x=res.find(x=>x.symbol===market);if(!x||!Array.isArray(x.history))throw Error('Coinalyze数据不可用');return x.history};
 return F.evaluate(r,h(oi5),h(oi15),h(v5),btcState(),Date.now());
}
async function scanFlow(silent=false){if(running)return;
 if(!canResearch()){if(!silent)show();status('请先保存Coinalyze API Key。');return}
 if(Date.now()-lastStarted<70000){if(!silent)show();status('Coinalyze请求间隔保护：距离上次不足70秒，暂不重复调用。');return}
 if(typeof scanning!=='undefined'&&scanning){if(!silent)show();status('原版Binance扫描仍在执行，请完成后再核查。');return}
 let now=Date.now();let selected=F.choose(rows,now).filter(x=>{try{return !pre15Filter(x.row).block}catch(e){return false}}).slice(0,8);
 if(!selected.length){scoreMap.clear();flags();draw();if(!silent)show();status('当前没有值得交易的候选，继续等待。原始数据过期或前置过滤未通过。');return}
 running=true;lastStarted=Date.now();$('flowStart').disabled=true;if(!silent)show();scoreMap.clear();flags();draw();
 let completed=0,failed=0;
 try{
  status('正在核对Coinalyze的Binance USDT永续市场标识…');let markets=await loadMarkets();
  let selectedMarkets=selected.map(x=>({...x,market:F.mapMarkets(markets,x.row.symbol)}));
  let matches=selectedMarkets.filter(x=>x.market);
  if(!matches.length)throw Error('未找到可验证的币安永续市场代码，不允许混用其他交易所OI');
  const batches=[];for(let i=0;i<matches.length;i+=2)batches.push(matches.slice(i,i+2));
  for(let batch of batches){await Promise.all(batch.map(async item=>{
   try{let res=await fetchOne(item,item.market);scoreMap.set(item.row.symbol,res)}catch(e){failed++;scoreMap.set(item.row.symbol,{symbol:item.row.symbol,score:null,state:'核查失败',reasons:[],risks:[e.message||String(e)],when:Date.now()})}
   completed++;status('资金复核 '+completed+'/'+matches.length+' · 请求失败 '+failed+' · 仅已收盘数据');draw();flags();
  }))}
  if(matches.length<selected.length)status('完成 '+completed+' 个 · '+(selected.length-matches.length)+' 个无对应市场 · '+failed+' 个接口失败。无交易确认。');
  else status('完成 '+completed+' 个 · 失败 '+failed+'。绿色仅表示符合资金准备度，不是进场信号。');
  try{localStorage.setItem('flowPlusLastV32',JSON.stringify([...scoreMap.values()].slice(0,8)))}catch(e){}
 }catch(e){status('资金筛选未完成：'+(e.message||e)+'；旧扫描不受影响。')}
 finally{running=false;$('flowStart').disabled=false}
}
$('flowStart').onclick=()=>scanFlow(false);
// AI is strictly manual and never automatically changes the original two-model classification.
let aiPendingId='';
window.__flowAIResponse=function(id,ok,payload){if(id!==aiPendingId)return;aiPendingId='';busyAI=false;$('flowAI').disabled=false;
 if(!ok){status('AI批量复核失败：'+String(payload).slice(0,220));return}
 try{let data=JSON.parse(payload);if(!Array.isArray(data.results))throw Error('AI结果缺少results');
  for(let x of data.results){let r=scoreMap.get(x.symbol);if(r){r.ai={action:String(x.action||'继续观察').slice(0,36),summary:String(x.summary||'').slice(0,240),risks:Array.isArray(x.risks)?x.risks.slice(0,5):[]}}}
  status('AI独立完成批量风险复核（不等于交易信号）：'+String(data.overall||'').slice(0,140));draw();flags();
 }catch(e){status('AI响应格式异常：'+e.message)}
};
$('flowAI').onclick=()=>{
 if(busyAI){status('AI核查正在执行');return}
 if(!native()?.hasOpenAIKey?.()){show();status('请在原来的「AI设置」保存OpenAI API Key，再进行批量分析。');return}
 let candidates=[...scoreMap.values()].filter(x=>x.score!==null&&Date.now()-x.when<60_000).sort((a,b)=>b.score-a.score).slice(0,5);
 if(!candidates.length){status('先完成Coinalyze资金筛选；超过60秒的资金快照不能用于AI分析。');return}
 let btc=btcState();const context={generatedAt:new Date().toISOString(),dataNote:'5m/15m仅已收盘数据；CVD为主动成交量差额代理，非订单簿净流入；分数不是胜率',btc,
  symbols:candidates.map(x=>({symbol:x.symbol,score:x.score,state:x.state,coinalyze:{oi5:x.oi5,oi15:x.oi15,buy5:x.buy5,cvdProgress:x.cvdProgress,volumePulse:x.volPulse},reasons:x.reasons,risks:x.risks,binance:(()=>{let r=rows.find(y=>y.symbol===x.symbol);return r?{p5:r.p5,p15:r.p15,p24:r.p24,oi5:r.oi5,oi15:r.oi15,buy5:r.buy5,cvd5:r.cvd5}:null})()}))};
 let model=$('aiModel')?.value||'gpt-4.1-mini';let id='b'+Date.now();aiPendingId=id;busyAI=true;$('flowAI').disabled=true;status('AI正在核查资金持续性、BTC风险、是否提前启动及数据冲突…');
 try{native().reviewScreenAI(id,JSON.stringify(context),model)}catch(e){window.__flowAIResponse(id,false,String(e))}
};
$('flowExport').onclick=()=>{
 const payload={schema:'flowPlusV32',exportedAt:new Date().toISOString(),explanation:'仅独立研究数据；分数非回测胜率',results:[...scoreMap.values()]};
 if(typeof saveScannerJson==='function')saveScannerJson('FlowPlusV32_5m_'+Date.now()+'.json',payload);else status('当前运行环境不支持导出');
};
// Preserve existing onClick callback/scan behavior; only add optional post-scan work.
const oldRefresh=$('refresh').onclick;
if(typeof oldRefresh==='function')$('refresh').onclick=async function(){await oldRefresh.apply(this,arguments);if(saved.auto&&!running&&Date.now()-lastStarted>=70000&&rows.length)await scanFlow(true)};
try{let previous=JSON.parse(localStorage.getItem('flowPlusLastV32')||'[]');if(Array.isArray(previous)){
 for(const r of previous)if(r&&r.symbol&&Number.isFinite(r.when)&&Date.now()-r.when<2*60_000)scoreMap.set(r.symbol,r);
}}catch(e){}
const priorCloseOverlay=window.scannerCloseOverlay;window.scannerCloseOverlay=function(){if(overlay.classList.contains('show')){hide();return true}return typeof priorCloseOverlay==='function'?priorCloseOverlay():false};
flags();
})();
