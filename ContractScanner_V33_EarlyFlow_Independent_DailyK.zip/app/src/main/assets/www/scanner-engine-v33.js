/* V33 scanner orchestration: discovery ordering, diversified 1m lane,
 * timestamped spot OI observations, candidate refresh and resilient transport.
 * All scores are research priorities, never calibrated probabilities. */
(function(root){
'use strict';
const finite=Number.isFinite, num=x=>x==null||x===''?NaN:Number(x);
const change=(a,b)=>finite(a)&&finite(b)&&b>0?(a/b-1)*100:NaN;
const majors=new Set(['BTCUSDT','ETHUSDT','BNBUSDT']);
const bounded=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const cleanSymbol=s=>typeof s==='string'&&/^[A-Z0-9]{2,24}USDT$/.test(s);
function priority(r){
 if(!r||!cleanSymbol(r.symbol))return -1e8;
 if(r.symbol==='BTCUSDT')return 1e8;
 const p5=num(r.p5),p15=num(r.p15),p24=num(r.p24),oi5=num(r.oi5),oi15=num(r.oi15),pulse=num(r.volPulse5),buy=num(r.buy5),usd=num(r.oiUsd);
 if(![p5,p15,p24,oi5,oi15,pulse,buy,usd].every(finite))return -1e6;
 if(majors.has(r.symbol)||Math.abs(p5)>1.7||Math.abs(p15)>4||Math.abs(p24)>19||usd<1_500_000||num(r.maxBody5)>=1.5||num(r.maxRange5)>5.5||pulse>4.5)return -1e6;
 let score=0;
 score+=p5>=-.45&&p5<=.9?12:0;
 score+=bounded(oi5*12,-12,20)+bounded(oi15*3,-8,12);
 score+=oi5>Math.abs(p5)*1.5&&oi5>.20?9:0;
 score+=pulse>=1.05&&pulse<=2.7?12:pulse<.35?-6:0;
 score+=bounded((buy-50)*1.0,-7,9);
 score+=bounded(num(r.cvd5)||0,-6,6);
 score+=usd>=5_000_000?6:0;
 // Actual Binance spot-OI snapshots take priority only when sampled recently.
 if(finite(r.oiSnap3)&&Date.now()-r.oiSnapTime<260000){score+=bounded(r.oiSnap3*19,-7,20);if(r.oiSnap3>.25&&p5<.8)score+=10;}
 return score;
}
function eligible(r,now,maxAge=90000){
 return r&&cleanSymbol(r.symbol)&&!majors.has(r.symbol)&&finite(r.sampledAt)&&now-r.sampledAt>=-3000&&now-r.sampledAt<=maxAge&&
 [r.p5,r.p15,r.p24,r.oi5,r.oi15,r.oiUsd,r.maxBody5,r.buy5].every(finite)&&
 Math.abs(r.p5)<=1.35&&Math.abs(r.p15)<=3.2&&Math.abs(r.p24)<=15&&r.maxBody5<1.35&&r.oiUsd>=1_500_000&&
 (!finite(r.maxRange5)||r.maxRange5<=5.5)&&(!finite(r.volPulse5)||r.volPulse5<=5);
}
// Do not starve activity-first candidates simply because 5m OI has not registered growth.
function selectMinute(rows,now,max=4){
 let candidates=Array.isArray(rows)?rows.filter(r=>eligible(r,now,60000)):[];
 const a=candidates.filter(r=>r.oi5>=.15&&r.oi15>=.15)
   .map(r=>({row:r,rank:priority(r),lane:'5m-OI'})).sort((x,y)=>y.rank-x.rank);
 const b=candidates.filter(r=>r.oi5>=-.25&&r.oi15>=-.35&&r.buy5>=45&&r.p5>=-.45&&r.p5<=.85)
   .map(r=>({row:r,rank:priority(r)+(r.volPulse5>=1.1&&r.volPulse5<=2.8?8:0)+
      (finite(r.oiSnap1)&&r.oiSnap1>.06?14:0),lane:'activity'})).sort((x,y)=>y.rank-x.rank);
 let chosen=[],used=new Set();
 const take=(pool,limit)=>{for(const item of pool){if(chosen.length>=limit)break;if(!used.has(item.row.symbol)){used.add(item.row.symbol);chosen.push(item)}}};
 take(a,Math.min(2,max));take(b,max);take(a,max);
 return chosen.slice(0,max);
}
function selectWatch(rows,now,max=8){
 if(!Array.isArray(rows))return [];
 // Expired rows can be refreshed; expiry prevents trading signals, not repair.
 const valid=rows.filter(r=>r&&cleanSymbol(r.symbol)&&!majors.has(r.symbol)&&finite(r.sampledAt)&&now-r.sampledAt>=-3000&&now-r.sampledAt<20*60000&&
 finite(r.oiUsd)&&r.oiUsd>=1_500_000&&finite(r.p5)&&Math.abs(r.p5)<1.8&&finite(r.p24)&&Math.abs(r.p24)<19);
 const first=valid.filter(r=>r.oi5>=.18).sort((a,b)=>priority(b)-priority(a));
 const activity=valid.filter(r=>r.volPulse5>=1.05&&r.volPulse5<=3.8).sort((a,b)=>priority(b)-priority(a));
 const out=[],used=new Set();const add=(pool,until)=>{for(const r of pool){if(out.length>=until)break;if(!used.has(r.symbol)){used.add(r.symbol);out.push(r.symbol)}}};
 add(first,Math.min(4,max));add(activity,max);add(valid.sort((a,b)=>priority(b)-priority(a)),max);
 return out.slice(0,max);
}
function orderSymbols(symbols,byTicker,priorRows=[],now=Date.now()){
 const old=new Map(priorRows.filter(r=>r&&r.symbol).map(r=>[r.symbol,r]));
 const scored=(Array.isArray(symbols)?symbols:[]).map((symbol,index)=>{
  let t=byTicker instanceof Map?byTicker.get(symbol):byTicker?.[symbol],score=0;
  if(symbol==='BTCUSDT')return {symbol,index,score:1e10};
  if(majors.has(symbol))score-=150;
  if(t){
   const vol=num(t.quoteVolume),p=num(t.priceChangePercent),hi=num(t.highPrice),lo=num(t.lowPrice),close=num(t.lastPrice);
   const amplitude=close>0&&hi>=lo?100*(hi-lo)/close:NaN;
   if(finite(vol)){score+=vol>=3_000_000?24:vol>=1_000_000?10:-20;score+=vol>2e9?-10:0;score+=vol>=5_000_000&&vol<=400_000_000?7:0;}
   if(finite(p))score+=Math.abs(p)<=12?10:Math.abs(p)>25?-40:-8;
   if(finite(amplitude))score+=amplitude<=20?5:-14;
  }
  let r=old.get(symbol);if(r&&now-r.sampledAt<6*60000)score+=bounded(priority(r),-30,80);
  return {symbol,index,score};
 });
 return scored.sort((a,b)=>b.score-a.score||a.index-b.index).map(x=>x.symbol);
}
// One bulk 24h ticker snapshot can highlight emerging movement between scans.
// This is a PRICE change over the observed elapsed time, NOT 1m trade volume.
function discoverTickerChanges(previous,current,now,max=2){
 if(!(previous instanceof Map)||!(current instanceof Map))return [];
 const dt=current.updatedAt-previous.updatedAt;
 if(!finite(dt)||dt<40000||dt>240000)return [];
 const out=[];
 for(const [symbol,t] of current){
  if(!cleanSymbol(symbol)||majors.has(symbol))continue;
  const old=previous.get(symbol);if(!old)continue;
  const last=num(t.lastPrice),prior=num(old.lastPrice),vol=num(t.quoteVolume),p24=num(t.priceChangePercent),high=num(t.highPrice),low=num(t.lowPrice);
  const delta=change(last,prior),amplitude=last>0?100*(high-low)/last:NaN;
  if(![last,prior,vol,p24,delta,amplitude].every(finite))continue;
  if(vol<3_000_000||Math.abs(p24)>15||amplitude>25||Math.abs(delta)<.07||Math.abs(delta)>.75)continue;
  out.push({symbol,delta,elapsedMs:dt,rank:Math.abs(delta)*35+bounded(Math.log10(vol/1e6),0,3)*4-(Math.abs(p24)>10?5:0)});
 }
 return out.sort((a,b)=>b.rank-a.rank).slice(0,max);
}
function validHistoricalOI(h,now){
 if(!Array.isArray(h)||h.length<4)return false;
 const points=h.slice(-4);let t=points.map(x=>num(x.timestamp));
 if(t.some(x=>!finite(x))||t.at(-1)>now+60000||now-t.at(-1)>12*60000)return false;
 for(let i=1;i<t.length;i++)if(Math.abs(t[i]-t[i-1]-300000)>1500)return false;
 return points.every(x=>finite(num(x.sumOpenInterest))&&num(x.sumOpenInterest)>0&&finite(num(x.sumOpenInterestValue)));
}
class OISnapshots{
 constructor(){this.data=new Map();}
 add(symbol,value,time){
  const v=num(value),t=num(time);if(!cleanSymbol(symbol)||!finite(v)||v<=0||!finite(t))return null;
  const history=this.data.get(symbol)||[];
  if(history.length&&t<=history.at(-1).t+45000)return this.metrics(symbol,t);
  history.push({t,v});this.data.set(symbol,history.filter(x=>t-x.t<=600000).slice(-12));
  if(this.data.size>80){for(const [key,points] of this.data)if(!points.length||t-points.at(-1).t>600000)this.data.delete(key)}
  return this.metrics(symbol,t);
 }
 metrics(symbol,now){
  const h=this.data.get(symbol)||[],last=h.at(-1);
  if(!last||now-last.t>90000)return null;
  const match=(low,high,target)=>h.slice(0,-1).filter(x=>last.t-x.t>=low&&last.t-x.t<=high).sort((a,b)=>Math.abs(last.t-a.t-target)-Math.abs(last.t-b.t-target))[0];
  const one=match(45000,100000,60000),three=match(145000,245000,180000);
  return {oiSnap1:one?change(last.v,one.v):NaN,oiSnap3:three?change(last.v,three.v):NaN,oiSnapTime:last.t,oiSamples:h.length};
 }
}
let notBefore=0;
async function getJSON(url){
 for(let attempt=0;attempt<2;attempt++){
  let remain=notBefore-Date.now();
  if(remain>30000)throw new Error('Binance API限流冷却中，请不要反复刷新');
  if(remain>0)await new Promise(r=>setTimeout(r,remain));
  const controller=typeof AbortController==='function'?new AbortController():null;
  const timer=controller?setTimeout(()=>controller.abort(),14000):null;
  try{
   const response=await fetch(url,{cache:'no-store',...(controller?{signal:controller.signal}:{})});
   if(response.ok)return await response.json();
   const retry=response.status===429||response.status>=500;
   if(response.status===429||response.status===418){
    let after=Number(response.headers?.get('Retry-After'));
    // A 418 is an IP ban: stop immediately rather than retrying an already banned endpoint.
    notBefore=Date.now()+(response.status===418?Math.max(300000,finite(after)&&after>0?after*1000:0):bounded(finite(after)&&after>0?after*1000:3500,2000,120000));
   }
   if(!retry||attempt===1)throw new Error('HTTP '+response.status);
  }catch(e){if(attempt===1||String(e.message||'').startsWith('HTTP 4'))throw e;}
  finally{if(timer)clearTimeout(timer)}
  await new Promise(r=>setTimeout(r,550+attempt*700));
 }
 throw new Error('请求失败');
}
const api={priority,eligible,selectMinute,selectWatch,orderSymbols,discoverTickerChanges,validHistoricalOI,OISnapshots,getJSON};
root.ScannerEngineV33=api;
if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
