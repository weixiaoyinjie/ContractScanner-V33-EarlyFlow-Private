package com.contractresearch.flowplusminute;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final String CHANNEL="flowplusminute_market_alert";
    private static final String HOME="https://appassets.androidplatform.net/assets/www/index.html";
    private static final String KEYSTORE="AndroidKeyStore";
    private static final String KEY_ALIAS="FlowPlusV32MinuteAES";
    private final ExecutorService executor=Executors.newFixedThreadPool(4);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private WebView browser;
    private boolean pageLoaded=false;
    // All Coinalyze calls within this APK share one conservative weighted quota.
    // Official accounting: each requested symbol is one API call.
    private static final int COINALYZE_MAX_COST=36;
    private static final long COINALYZE_WINDOW_MS=61_000L;
    private final Object coinalyzeRateLock=new Object();
    private final ArrayDeque<long[]> coinalyzeRate=new ArrayDeque<>();

    private final Set<String> coinalyzePaths=new HashSet<>(Arrays.asList(
        "future-markets","open-interest-history","ohlcv-history","funding-rate","liquidation-history"));

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff07101d);
        getWindow().setNavigationBarColor(0xff07101d);
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"合约市场风险提示",NotificationManager.IMPORTANCE_HIGH));
        }
        browser=new WebView(this);
        browser.setBackgroundColor(0xff07101d);
        WebSettings ws=browser.getSettings();
        ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setMediaPlaybackRequiresUserGesture(true);
        browser.addJavascriptInterface(new Bridge(),"ScannerNative");
        WebViewAssetLoader assetLoader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        browser.setWebChromeClient(new WebChromeClient());
        browser.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                if(u!=null&&"appassets.androidplatform.net".equals(u.getHost())&&"https".equals(u.getScheme()))return false;
                if(u!=null&&("https".equals(u.getScheme())||"http".equals(u.getScheme()))){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){
                if(HOME.equals(url)){pageLoaded=true;eval("if(window.ScannerApp)window.ScannerApp.nativeReady()");}
            }
        });
        setContentView(browser);
        browser.loadUrl(HOME);
    }
    private void eval(String javascript){ui.post(()->{if(browser!=null)browser.evaluateJavascript(javascript,null);});}
    private void respond(String callback,String req,boolean good,String data){
        eval("if(window."+callback+")window."+callback+"("+JSONObject.quote(req)+","+(good?"true":"false")+","+JSONObject.quote(data)+")");
    }
    @Override protected void onPause(){super.onPause();if(pageLoaded)eval("window.ScannerApp&&window.ScannerApp.onPause()");}
    @Override protected void onResume(){super.onResume();if(pageLoaded)eval("window.ScannerApp&&window.ScannerApp.onResume()");}
    @Override public void onBackPressed(){
        if(browser!=null){browser.evaluateJavascript("(function(){return !!(window.scannerCloseOverlay&&window.scannerCloseOverlay())})()",r->{
            if(!"true".equals(r)){if(browser.canGoBack())browser.goBack();else superBack();}
        });}else superBack();
    }
    private void superBack(){super.onBackPressed();}
    @Override protected void onDestroy(){executor.shutdownNow();if(browser!=null){browser.removeJavascriptInterface("ScannerNative");browser.destroy();browser=null;}super.onDestroy();}

    private SecretKey cipherKey() throws Exception{
        KeyStore ks=KeyStore.getInstance(KEYSTORE);ks.load(null);
        if(ks.containsAlias(KEY_ALIAS))return (SecretKey)ks.getKey(KEY_ALIAS,null);
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KEYSTORE);
        gen.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return gen.generateKey();
    }
    private void saveSecret(String name,String secret) throws Exception {
        if(secret==null||secret.isEmpty()||secret.length()>350)throw new Exception("密钥格式无效");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,cipherKey());
        byte[] encrypted=c.doFinal(secret.getBytes(StandardCharsets.UTF_8));
        getPreferences(MODE_PRIVATE).edit().putString(name+"iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP))
            .putString(name+"data",Base64.encodeToString(encrypted,Base64.NO_WRAP)).apply();
    }
    private String readSecret(String name){try{
        String d=getPreferences(MODE_PRIVATE).getString(name+"data","");String iv=getPreferences(MODE_PRIVATE).getString(name+"iv","");
        if(d.isEmpty()||iv.isEmpty())return "";
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE,cipherKey(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(d,Base64.NO_WRAP)),StandardCharsets.UTF_8);
    }catch(Exception e){return "";}}
    private void deleteSecret(String n){getPreferences(MODE_PRIVATE).edit().remove(n+"iv").remove(n+"data").apply();}
    private static String response(HttpURLConnection con) throws Exception {
        int status=con.getResponseCode();
        InputStream is=(status>=200&&status<300)?con.getInputStream():con.getErrorStream();
        if(is==null)throw new Exception("HTTP "+status);
        StringBuilder sb=new StringBuilder();
        try(BufferedReader in=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){
            char[] buf=new char[8192];int n;while((n=in.read(buf))!=-1){sb.append(buf,0,n);if(sb.length()>2_000_000)throw new Exception("响应过大");}
        }
        if(status<200||status>=300){
            String retry=con.getHeaderField("Retry-After");
            throw new Exception("HTTP "+status+(status==429&&retry!=null?"，请等待"+retry+"秒":"")+"："+sb.substring(0,Math.min(140,sb.length())));
        }
        return sb.toString();
    }
    private static HttpURLConnection conn(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);
        c.setRequestProperty("Accept","application/json");c.setUseCaches(false);return c;
    }
    private void reserveCoinalyzeQuota(String path,JSONObject args) throws Exception{
        int cost=1;
        if(!"future-markets".equals(path)){
            String symbols=args.optString("symbols","");
            if(symbols.isEmpty())throw new Exception("缺少交易对symbols");
            String[] selected=symbols.split(",",-1);
            if(selected.length>20)throw new Exception("每次最多20个交易对");
            for(String symbol:selected){
                if(!symbol.matches("[A-Za-z0-9_.-]{3,45}"))throw new Exception("交易对格式无效");
            }
            cost=selected.length;
        }
        long now=android.os.SystemClock.elapsedRealtime();
        synchronized(coinalyzeRateLock){
            while(!coinalyzeRate.isEmpty()&&now-coinalyzeRate.peekFirst()[0]>=COINALYZE_WINDOW_MS)
                coinalyzeRate.removeFirst();
            int used=0;
            for(long[] e:coinalyzeRate)used+=(int)e[1];
            if(used+cost>COINALYZE_MAX_COST){
                long remaining=coinalyzeRate.isEmpty()?60:(COINALYZE_WINDOW_MS-(now-coinalyzeRate.peekFirst()[0]))/1000+1;
                throw new Exception("本机Coinalyze额度保护：约"+Math.max(1,remaining)+"秒后再试（按币种计算）");
            }
            coinalyzeRate.addLast(new long[]{now,cost});
        }
    }
    private String coinalyze(String path,String arguments) throws Exception {
        if(!coinalyzePaths.contains(path))throw new Exception("接口不受允许");
        String key=readSecret("coinalyze");if(key.isEmpty())throw new Exception("未设置Coinalyze密钥");
        JSONObject args=new JSONObject(arguments);
        Set<String> allowed=new HashSet<>(Arrays.asList("symbols","interval","from","to","convert_to_usd"));
        StringBuilder url=new StringBuilder("https://api.coinalyze.net/v1/").append(path);
        int k=0;
        for(java.util.Iterator<String> fields=args.keys();fields.hasNext();){
            String field=fields.next();
            if(!allowed.contains(field))throw new Exception("参数不受允许");
            String val=args.getString(field);
            if(val.length()>230)throw new Exception("参数过长");
            url.append(k++==0?'?':'&').append(java.net.URLEncoder.encode(field,"UTF-8"))
                .append('=').append(java.net.URLEncoder.encode(val,"UTF-8"));
        }
        reserveCoinalyzeQuota(path,args);
        HttpURLConnection c=conn(url.toString());
        try{c.setRequestProperty("api_key",key);return response(c);}finally{c.disconnect();}
    }
    private static JSONObject arraySchema(){
        JSONObject schema=new JSONObject();
        try{schema.put("type","array");schema.put("items",new JSONObject().put("type","string"));}catch(Exception ignored){}
        return schema;
    }
    private static JSONObject objectSchema(JSONObject properties,String... required) throws Exception {
        return new JSONObject().put("type","object").put("properties",properties)
            .put("required",new JSONArray(Arrays.asList(required))).put("additionalProperties",false);
    }
    private static JSONObject stringSchema() throws Exception {return new JSONObject().put("type","string");}
    private static JSONObject aiSingleSchema() throws Exception {
        JSONObject p=new JSONObject();
        for(String key:new String[]{"grade","bias","action","summary"})p.put(key,stringSchema());
        for(String key:new String[]{"evidence","risks","missingData","conditions"})p.put(key,arraySchema());
        return objectSchema(p,"grade","bias","action","summary","evidence","risks","missingData","conditions");
    }
    private static JSONObject aiBatchSchema() throws Exception {
        JSONObject p=new JSONObject().put("symbol",stringSchema()).put("action",stringSchema())
            .put("summary",stringSchema()).put("risks",arraySchema());
        JSONObject entry=objectSchema(p,"symbol","action","summary","risks");
        JSONObject list=new JSONObject().put("type","array").put("items",entry);
        return objectSchema(new JSONObject().put("results",list).put("overall",stringSchema()),"results","overall");
    }
    private String review(String snapshot,String model,boolean batch) throws Exception{
        String key=readSecret("openai");if(key.isEmpty())throw new Exception("未设置OpenAI API Key");
        if(!"gpt-4.1-mini".equals(model)&&!"gpt-4o-mini".equals(model))model="gpt-4.1-mini";
        if(snapshot==null||snapshot.length()>50000)throw new Exception("研究快照过长");
        String policy=batch?
          "你是独立的永续合约短线风险审查器。仅依据用户提交的JSON候选快照逐个审查。优先识别5-15分钟初始启动前半段。价格上涨/OI上涨都不能单独判方向；若输入有1m OI与1m主动成交快照，须结合5m/15m结构识别虚假1m突变；同时检查主动买盘、CVD差额、15m结构、BTC风险、是否已经过热、数据时间和冲突。明确区分观察和确认。不要编造历史或胜率。action只能使用继续观察/排除/人工复查/已启动不追，不要提供自动下单建议。只返回JSON；每个候选symbol必须在原输入中。":"你是独立的永续合约超短线研究风险复核员。只依据快照分析，OI不直接表方向，CVD是主动成交代理而非逐笔CVD。重视5m和15m OI、买卖主动量、BTC风险、过热以及不足的数据；保守评级A/B/C/PASS，等级不代表胜率；不存在可靠方向时必须PASS/观察。只返回符合schema的JSON。";
        JSONObject data=new JSONObject().put("model",model).put("instructions",policy)
            .put("input",snapshot).put("store",false)
            .put("text",new JSONObject().put("format",new JSONObject().put("type","json_schema")
                .put("name",batch?"flow_batch_risk_review":"flow_coin_risk_review")
                .put("strict",true).put("schema",batch?aiBatchSchema():aiSingleSchema())));
        HttpURLConnection c=conn("https://api.openai.com/v1/responses");
        try{
            c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+key);
            try(OutputStream out=c.getOutputStream()){out.write(data.toString().getBytes(StandardCharsets.UTF_8));}
            JSONObject result=new JSONObject(response(c));
            // Responses API: output[].content[].text of type output_text.
            JSONArray output=result.optJSONArray("output");
            if(output!=null)for(int i=0;i<output.length();i++){
                JSONArray content=output.optJSONObject(i)!=null?output.getJSONObject(i).optJSONArray("content"):null;
                if(content==null)continue;
                for(int j=0;j<content.length();j++){
                    JSONObject item=content.optJSONObject(j);
                    if(item!=null&&"output_text".equals(item.optString("type"))){
                        String raw=item.optString("text","");new JSONObject(raw);return raw;
                    }
                }
            }
            throw new Exception("AI未返回可解析的结构化结果");
        }finally{c.disconnect();}
    }
    private void toast(String s){ui.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private final class Bridge {
        @JavascriptInterface public String saveOpenAIKey(String value){try{saveSecret("openai",value.trim());return "OK";}catch(Exception e){return "保存失败："+e.getMessage();}}
        @JavascriptInterface public boolean hasOpenAIKey(){return !readSecret("openai").isEmpty();}
        @JavascriptInterface public void deleteOpenAIKey(){deleteSecret("openai");}
        @JavascriptInterface public String saveCoinalyzeKey(String value){try{saveSecret("coinalyze",value.trim());return "OK";}catch(Exception e){return "保存失败："+e.getMessage();}}
        @JavascriptInterface public boolean hasCoinalyzeKey(){return !readSecret("coinalyze").isEmpty();}
        @JavascriptInterface public void deleteCoinalyzeKey(){deleteSecret("coinalyze");}
        @JavascriptInterface public void coinalyzeGet(String id,String path,String params){
            String callback=id!=null&&id.startsWith("minute-")?"__minuteApiResult":"__flowApiResult";
            executor.execute(()->{try{respond(callback,id,true,coinalyze(path,params));}
                catch(Exception e){respond(callback,id,false,e.getMessage()==null?"网络异常":e.getMessage());}});
        }
        @JavascriptInterface public void reviewCoinAI(String id,String snapshot,String model){
            executor.execute(()->{try{respond("__scannerAIResponse",id,true,review(snapshot,model,false));}
                catch(Exception e){respond("__scannerAIResponse",id,false,e.getMessage()==null?"请求失败":e.getMessage());}});
        }
        @JavascriptInterface public void reviewMinuteAI(String id,String snapshot,String model){
            executor.execute(()->{try{respond("__minuteAIResponse",id,true,review(snapshot,model,true));}
                catch(Exception e){respond("__minuteAIResponse",id,false,e.getMessage()==null?"请求失败":e.getMessage());}});
        }
        @JavascriptInterface public void reviewScreenAI(String id,String snapshot,String model){
            executor.execute(()->{try{respond("__flowAIResponse",id,true,review(snapshot,model,true));}
                catch(Exception e){respond("__flowAIResponse",id,false,e.getMessage()==null?"请求失败":e.getMessage());}});
        }
        @JavascriptInterface public boolean copyCoinSymbol(String coin){
            if(coin==null||!coin.matches("[A-Z0-9]{2,24}"))return false;
            ui.post(()->{ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("币种",coin));});return true;
        }
        @JavascriptInterface public void openBinanceFutures(String symbol,String unused){
            if(symbol==null||!symbol.matches("[A-Z0-9]{2,24}USDT"))return;
            ui.post(()->{try{
                Intent in=getPackageManager().getLaunchIntentForPackage("com.binance.dev");
                if(in!=null){in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(in);}
                else toast("没有找到币安App，请先安装币安官方应用");
            }catch(Exception e){toast("无法打开币安App："+e.getMessage());}});
        }
        @JavascriptInterface public boolean hasNotificationPermission(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
        @JavascriptInterface public void requestNotifications(){ui.post(()->{
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},52);
            else toast("通知权限已开启");
        });}
        @JavascriptInterface public void notifyRisk(String title,String detail){ui.post(()->{
            if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            Intent intent=new Intent(MainActivity.this,MainActivity.class);
            PendingIntent pi=PendingIntent.getActivity(MainActivity.this,0,intent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n=new Notification.Builder(MainActivity.this,CHANNEL)
                .setSmallIcon(com.contractresearch.flowplusminute.R.drawable.ic_scanner).setContentTitle(title)
                .setContentText(detail).setStyle(new Notification.BigTextStyle().bigText(detail))
                .setAutoCancel(true).setContentIntent(pi).build();
            ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(1402,n);
        });}
        @JavascriptInterface public void saveJson(String filename,String content){
            if(content==null||content.length()>5_000_000){toast("导出文件过大");return;}
            String clean=filename==null?"flowplus.json":filename.replaceAll("[^A-Za-z0-9_.-]","_");
            if(!clean.endsWith(".json"))clean+=".json";
            final String name=clean;
            executor.execute(()->{try{
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,"application/json");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/ContractScanner/");
                    Uri file=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(file==null)throw new Exception("无法创建下载文件");
                    try(OutputStream out=getContentResolver().openOutputStream(file)){if(out==null)throw new Exception("无法写入");out.write(content.getBytes(StandardCharsets.UTF_8));}
                }else{
                    java.io.File folder=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);if(folder==null)throw new Exception("存储不可用");
                    java.io.File file=new java.io.File(folder,name);
                    try(OutputStream out=new java.io.FileOutputStream(file)){out.write(content.getBytes(StandardCharsets.UTF_8));}
                }
                toast("已导出："+name);
            }catch(Exception e){toast("导出失败："+e.getMessage());}});
        }
    }
}
