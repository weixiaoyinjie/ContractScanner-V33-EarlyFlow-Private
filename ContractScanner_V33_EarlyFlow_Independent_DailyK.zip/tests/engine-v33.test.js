const assert=require('node:assert/strict');
const E=require('../app/src/main/assets/www/scanner-engine-v33.js');
const now=Date.now();
const base={symbol:'AAAUSDT',sampledAt:now-2000,p5:.2,p15:.5,p24:2.0,oi5:.6,oi15:.8,oiUsd:7e6,maxBody5:.3,maxRange5:1.0,volPulse5:1.4,buy5:56,cvd5:1.3};
const activity={...base,symbol:'BBBFFFUSDT',oi5:.04,oi15:.06,buy5:51,cvd5:.15,volPulse5:2.1};
const slow={...base,symbol:'CCCUSDT',oi5:0.0,oi15:.04,buy5:50,volPulse5:.4};
assert.deepEqual(E.orderSymbols(['LOWUSDT','BTCUSDT','HOTUSDT'], new Map([
 ['LOWUSDT',{quoteVolume:'3000',priceChangePercent:'2',highPrice:'104',lowPrice:'100',lastPrice:'102'}],
 ['HOTUSDT',{quoteVolume:'15000000',priceChangePercent:'1',highPrice:'103',lowPrice:'100',lastPrice:'101'}]]))[0],'BTCUSDT');
assert.equal(E.selectMinute([activity],now).length,1,'new discovery lane accepts weak 5m OI but active volume');
assert.equal(E.selectMinute([{...activity,p5:2.5}],now).length,0,'never bypass overheat filter');
assert.equal(E.selectMinute([{...activity,symbol:'ETHUSDT'}],now).length,0,'major tokens excluded');
assert.equal(E.selectMinute([{...activity,sampledAt:now-65_000}],now).length,0,'stale data is not an entry');
const four=E.selectMinute([base,activity,slow,{...base,symbol:'DDDUSDT',oi5:.7},{...base,symbol:'EEEUSDT',oi5:.9}],now);
assert.equal(four.length,4);
assert.ok(four.some(x=>x.row.symbol===activity.symbol),'activity lane must survive competing 5m OI signals');
assert.ok(four.some(x=>x.lane==='5m-OI'));
assert.equal(new Set(four.map(x=>x.row.symbol)).size,4);
const watch=E.selectWatch([base,activity,{...base,symbol:'ZZZUSDT',p24:45}],now);
assert.ok(watch.includes(base.symbol)&&watch.includes(activity.symbol));
assert.ok(!watch.includes('ZZZUSDT'));
const t=now-now%300000;
const valid=Array.from({length:5},(_,i)=>({timestamp:t-(4-i)*300000,sumOpenInterest:String(200+i),sumOpenInterestValue:String(2e7)}));
assert.equal(E.validHistoricalOI(valid,now),true);
assert.equal(E.validHistoricalOI(valid.slice(1).map((x,i)=>i===2?{...x,timestamp:x.timestamp+120000}:x),now),false,'misaligned historical OI is not comparable');
assert.equal(E.validHistoricalOI(valid,now+16*60000),false,'stale OI is rejected');
const store=new E.OISnapshots();let value=1000;
assert.ok(Number.isNaN(store.add('AAAUSDT',value,now-180000).oiSnap1));
store.add('AAAUSDT',1002,now-120000);
store.add('AAAUSDT',1006,now-60000);
const m=store.add('AAAUSDT',1010,now);
assert.ok(m.oiSnap1>0&&m.oiSnap3>0,'minute and three-minute observed growth computed from clocked samples');
assert.ok(m.oiSnap3>m.oiSnap1);
assert.equal(store.add('BAD',100,now),null);
assert.equal(E.selectWatch([],now).length,0);
console.log('Scanner V33 engine tests passed');
const oldTickers=new Map([
 ['AAAUSDT',{lastPrice:'100',quoteVolume:'9000000'}],
 ['BBBFFFUSDT',{lastPrice:'101',quoteVolume:'9000000'}],
 ['BTCUSDT',{lastPrice:'70000',quoteVolume:'1000000000'}]]);
oldTickers.updatedAt=now-90_000;
const newTickers=new Map([
 ['AAAUSDT',{lastPrice:'100.25',quoteVolume:'9200000',priceChangePercent:'3',highPrice:'105',lowPrice:'98'}],
 ['BBBFFFUSDT',{lastPrice:'107',quoteVolume:'9200000',priceChangePercent:'3',highPrice:'108',lowPrice:'98'}],
 ['BTCUSDT',{lastPrice:'70010',quoteVolume:'1100000000',priceChangePercent:'.5',highPrice:'70500',lowPrice:'69000'}]]);
newTickers.updatedAt=now;
assert.deepEqual(E.discoverTickerChanges(oldTickers,newTickers,now).map(x=>x.symbol),['AAAUSDT'],'rolling ticker changes only discover calm new movement, never majors or >0.75% chase');
