const assert=require('node:assert/strict');
const F=require('../app/src/main/assets/www/flow-core.js');
const now=Date.parse('2026-10-29T12:00:00Z');
function history(seconds,values){const start=Math.floor(now/1000)-seconds*(values.length+1);return values.map((v,i)=>({t:start+seconds*i,c:v}));}
function flow(values){const start=Math.floor(now/1000)-300*(values.length+1);return values.map((x,i)=>({t:start+300*i,v:100,bv:x}));}
const row={symbol:'SOLUSDT',sampledAt:now-2000,p5:.33,p15:1.1,p24:3.1,oi5:1.4,oi15:2.2,oiUsd:5000000,maxBody5:.35,maxRange5:1.7,rise20:2.2,maxBull15:1.5,buy5:56,cvd5:3.4,volPulse5:1.5};
assert.equal(F.choose([row],now).length,1);
assert.equal(F.choose([{...row,p5:2.4}],now).length,0);
assert.equal(F.choose([{...row,symbol:'BTCUSDT'}],now).length,0);
assert.equal(F.mapMarkets([{exchange:'binance',symbol_on_exchange:'SOLUSDT',symbol:'SOLUSDT_PERP.A',is_perpetual:true,margined:'STABLE',quote_asset:'USDT'}],'SOLUSDT'),'SOLUSDT_PERP.A');
assert.equal(F.mapMarkets([{exchange:'bybit',symbol_on_exchange:'SOLUSDT',symbol:'SOLUSDT_PERP.9',is_perpetual:true,margined:'STABLE',quote_asset:'USDT'}],'SOLUSDT'),null);
const o5=history(300,[100,101,102,103,104,105]);const o15=history(900,[100,101,103,105]);
let v=F.evaluate(row,o5,o15,flow([49,50,53,54,56,59,60]),{healthy:true,shock:false,p5:0.2},now);
assert.ok(v.score>=60,JSON.stringify(v));
assert.ok(v.score<=100);
assert.equal(v.symbol,row.symbol);
assert.notEqual(v.state,'数据不足');
assert.equal(F.evaluate(row,o5,o15,flow([49,50,53,54,56,59,60]),{healthy:false,shock:true,p5:-2},now).state,'观察·冲突');
assert.equal(F.evaluate(row,[],[],[],{healthy:true,shock:false,p5:0},now).state,'数据不足');
console.log('FlowCore tests passed');
