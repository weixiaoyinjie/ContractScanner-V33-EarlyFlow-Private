const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'../app/src/main/assets/www');
const flow=fs.readFileSync(path.join(root,'flow-extension.js'),'utf8');
const minute=fs.readFileSync(path.join(root,'minute-extension.js'),'utf8');
const page=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const source of [flow,minute]){
  assert.ok(source.includes('data-quick-copy='),'result has copy-symbol control');
  assert.ok(source.includes('data-quick-binance='),'result has Binance-app control');
  assert.ok(source.includes('data-quick-jump='),'result has return-to-coin control');
}
assert.ok(page.includes('<script src="quick-nav.js"></script>'));
const callbacks={};let symbolCopied=null,binanceOpened=null;
const popup={classList:{removed:[],remove(...args){this.removed.push(...args)}}};
const target={
  children:[{getAttribute(){return 'APTUSDT'}}],
  querySelector(){return this.children[0]},
  scrollIntoView({block}){this.scrolled=block},
  classList:{added:[],add(c){this.added.push(c)},remove(){}}
};
let visible=false;
const list={querySelectorAll(){return visible?[target]:[]}};
const search={value:'BTC',dispatchEvent(e){visible=true;this.event=e.type}};
const els={body:list,search};
const document={
  getElementById(id){return els[id]||null},
  querySelector(){return null},
  addEventListener(name,handler){callbacks[name]=handler},
  createElement(){return {setAttribute(){},className:'',textContent:'',remove(){}}},
  body:{appendChild(){}}
};
const ctx={document,rows:[{symbol:'APTUSDT'}],
  window:{ScannerNative:{}},
  Event:class{constructor(type){this.type=type}},
  requestAnimationFrame:f=>f(),setTimeout:()=>{},
  copySymbol:el=>symbolCopied=el.dataset.copy,
  openBinanceFutures:sym=>binanceOpened=sym,
};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root,'quick-nav.js'),'utf8'),ctx);
function makeClick(dataset,attribute){
 const el={dataset,
   hasAttribute(attr){return attr===attribute},
   closest(sel){return sel==='#flowMask,#minuteMask'?popup:{}},
 };
 callbacks.click({target:{closest(){return el}},preventDefault(){},stopPropagation(){}});
}
makeClick({quickCopy:'APT'},'data-quick-copy');
assert.equal(symbolCopied,'APT');
makeClick({quickBinance:'APTUSDT'},'data-quick-binance');
assert.equal(binanceOpened,'APTUSDT');
makeClick({quickJump:'APTUSDT'},'data-quick-jump');
assert.equal(search.value,'');
assert.equal(search.event,'input');
assert.equal(target.scrolled,'center');
assert.ok(target.classList.added.includes('quickNavTarget'));
assert.ok(popup.classList.removed.includes('show'));
assert.ok(popup.classList.removed.includes('open'));
console.log('V32.1 quick navigation tests passed');
