const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const folder=path.join(__dirname,'../app/src/main/assets/www');
const h=fs.readFileSync(path.join(folder,'index.html'),'utf8');
const js=h.match(/<script>([\s\S]*?)<\/script>/)?.[1];
assert.ok(js,'original application inline JS exists');
new vm.Script(js,'index.html');
assert.match(h,/scanMetricCell\('p24','价格 24h',[\s\S]*?data-k="1d" data-symbol="\$\{r\.symbol\}"/,'ALL-coin 24h metric still links to daily candlestick');
assert.match(h,/let kc=e\.target\.closest\('\.kcell'\);if\(kc\)\{openK\(kc\.dataset\.symbol,kc\.dataset\.k\)/,'daily K click dispatcher remains');
assert.match(h,/interval==='1d'\?90:60/,'90 daily candles remain');
assert.match(h,/timeZone:'UTC'/,'UTC daily candlestick labels remain');
for(const file of ['flow-core.js','flow-extension.js','minute-core.js','minute-extension.js','quick-nav.js','scanner-engine-v33.js','ai-module.js']){
 new vm.Script(fs.readFileSync(path.join(folder,file),'utf8'),file);
}
assert.match(h,/script src="scanner-engine-v33\.js"/);
assert.match(h,/data-oi="5m"/);
assert.match(h,/data-oi="15m"/);
assert.match(h,/结构复查/);
assert.match(h,/🤖 AI分析/);
const ext=fs.readFileSync(path.join(folder,'minute-extension.js'),'utf8');
assert.match(ext,/selectMinute\(rows,Date\.now\(\)\)/,'1m uses diversified discovery');
console.log('Scanner V33 UI and daily-K regression tests passed');
