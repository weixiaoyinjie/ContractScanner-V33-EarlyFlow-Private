# 合约扫描器 V33.0 · EarlyFlow 独立安装版

以用户提供的 **ContractScanner_V32_1_AllCoins_24h_DailyK.zip** 为完整母版，保留原版布局、列、弹窗、按钮和快捷导航；原APK内核心网页资源已核对与上传ZIP完全一致。

## Android身份

- 应用名称：**合约扫描器·V33资金引擎**
- `applicationId`: **`com.contractresearch.scannerv33.earlyflow`**
- `namespace`: `com.contractresearch.flowplusminute`（保留原有 Java 类名以避免破坏代码，不影响并行安装）
- `versionCode`: `3301`
- `versionName`: `33.0-earlyflow-independent`
- 原 V32.1 App 不会被覆盖，两款 App 各自保存 API Key、设置与研究数据。

## 不变的界面功能

1. **每一行的“价格24h”涨跌数字均带 `data-k="1d"`，点击打开该币最近90根UTC日K蜡烛图**；BTC和所有其他已扫描币一样有效。
2. 点击价格5m/15m数值对应K线，OI5m/OI15m对应OI曲线，CVD对应CVD图。
3. 原5m资金+、1m资金预警、AI单币分析、批量复核、结构复查、追踪、BTC防御、风险计划、JSON导出、Binance App启动和快速返回定位都保留。
4. 未改动MainActivity.java，继续使用原来的 Android Keystore、Coinalyze限额保护、Android 资产加载方式以及GitHub Actions Gradle编译。

## 已实际修改的筛选引擎

| 范围 | 改动 | 目的与边界 |
|---|---|---|
| P0 | 首批市场扫描通过 Binance 批量24h成交额/价格振幅/涨幅排序，BTC置顶；全部合格USDT永续仍照常扫描 | 优先研究相对冷静、流动性可用的币，不因排序影响主列表功能 |
| P0 | 网络请求支持超时、一次重试、429/5xx冷却；OI历史检查时间戳、连续的5m区间与最大数据延迟 | 避免间断/过期OI被误当连续仓位变化 |
| P0 | Coinalyze 5m前置15m过滤在最终取前8之前执行，候选预选池从10扩大至30 | 防止前排已过热币挤占剩余位置 |
| P0 | Coinalyze 5m / 15m / OHLCV检查已收盘数据相邻时间间隔、加强新鲜度标准 | 不把缺失区间拼接成资金持续性；延迟数据只作观察 |
| P0 | Coinalyze资金强度比较使用成交差额/总成交额的相对强度，删除15m OI双重加分 | 减少单纯放量导致的错误偏差及同一指标重复记分 |
| P1 | 基础扫描时动态优先级；扫描后每45秒小批量复查最多8个高优先级币 | 不必为观察重点候选而重新跑完整市场 |
| P1 | 对比连续两次批量24h ticker 的价格快照，最多引入2个新的温和变化币进入定时复查队列 | 增加新出现价格变化的候选发现，不把滚动24h交易量差额冒充1m成交量 |
| P2 | 1m Coinalyze复核每次4个币；前两席优先5m-OI候选，其余优先温和价格+活跃度候选 | 不再只能从旧5m OI排名前4中挑选1m候选 |
| P2 | 每60秒对重点池最多8币读取 Binance `/fapi/v1/openInterest` 的真实时间戳OI快照 | 建立约1m/3m OI变化的本机观察序列；数据不足直接保持不可用，不伪造历史 |

**风险提示**：优先级分数不代表胜率或入场建议。OI只代表仓位变化，不直接确定方向。所有市场数据必须在手机上实际联网验证。应用不自动下单。

## 运行与API条件

- Binance基础扫描必须能访问 `fapi.binance.com`，使用 `/fapi/v1/exchangeInfo`、批量24h、`klines` 和 `/futures/data/openInterestHist` 等公开端点。
- 实时OI观察使用 `/fapi/v1/openInterest?symbol=...`；每个交易对按观察周期请求。首次运行需要累积足够时间戳样本，不能立即得到3分钟OI增速。
- 原Coinalyze 1m和5m资金增强模块仍需用户自行在App内部输入自己的Coinalyze Key；原原生限额仍然存在（每次合并请求按币数消耗配额）。
- 原OpenAI AI分析功能仍需用户自己的API Key，绝不写在ZIP或源码中。
- App仅在前台的可见WebView中定时跟踪。被系统暂停、断网、接口限流或退出App后，不会继续后台扫描。
- 全市场扫描仍需要逐币请求；此次优先优化最早发现与候选维护，**并未实现全市场实时WebSocket订阅或经实盘验证的盈利率提升**。
- `GET /futures/data/openInterestHist` 官方最小5m粒度；本App采集的分钟OI是独立定时的当前OI快照，不是该历史接口的1m数据。

## 构建独立APK（GitHub Actions）

建议新建**私有仓库**，保护策略代码，例如 `ContractScanner-V33-EarlyFlow-Private`。

1. 在 https://github.com/new 创建空的私有仓库。
2. 在电脑或手机中**先解压本ZIP**，将根目录内 `app/`、`tests/`、`.github/`、`build.gradle`、`settings.gradle`、`gradle.properties` 和 `README.md` 上传到仓库根目录。不要把ZIP作为唯一文件上传。
3. GitHub → **Actions** → **Build Android APK** → **Run workflow**，或直接push到`main`分支。
4. 等流程成功后在Artifacts下载 **`ContractScanner-V33-EarlyFlow-Independent-APK`**，解压获得 **`app-debug.apk`**。在手机安装，与V32.1共存。

Actions使用Android SDK 35、Java 17、Gradle 8.9；先执行以下全部Node.js测试，再调用 `gradle :app:assembleDebug`。

```bash
node tests/core.test.js
node tests/minute.test.js
node tests/quick-nav.test.js
node tests/engine-v33.test.js
node tests/ui-regression.test.js
```

## 已验证与尚未验证

- 已验证：原上传ZIP与APK的 `index.html`、`minute-extension.js`、`quick-nav.js` 字节一致；上述全部五组Node回归测试通过；所有脚本可通过语法分析；24h数字→日K的代码路径仍在。
- 尚未验证：本环境不含Android SDK或Gradle，未编出APK；也不能模拟真实Binance和Coinalyze联网结果以及在真机测量发现延迟/误报率。请使用Actions构建并在手机实测。
