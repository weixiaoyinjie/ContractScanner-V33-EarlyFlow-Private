package com.contractresearch.wear;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Four aligned panes: closed candle price, volume, historical OI and taker-volume CVD. */
final class StructureChartView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<WatchMetrics.Candle> bars=new ArrayList<>();
    private int selected=-1;
    private Consumer<WatchMetrics.Candle> onSelect;
    StructureChartView(Context context){super(context);}
    void data(List<WatchMetrics.Candle> source){
        bars=new ArrayList<>();if(source!=null){int begin=Math.max(0,source.size()-30);bars.addAll(source.subList(begin,source.size()));}
        selected=bars.size()-1;
        if(onSelect!=null&&selected>=0)onSelect.accept(bars.get(selected));
        invalidate();
    }
    void setOnSelect(Consumer<WatchMetrics.Candle> listener){onSelect=listener;}
    private void text(Canvas c,String str,float x,float y,int color,float size){p.setColor(color);p.setTextSize(size);p.setStyle(Paint.Style.FILL);c.drawText(str,x,y,p);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);canvas.drawColor(Color.rgb(8,24,40));
        final float w=getWidth(),h=getHeight(),left=6,right=w-8;
        final float priceTop=19,priceBottom=h*.43f,volTop=h*.49f,volBottom=h*.60f,oiTop=h*.67f,oiBottom=h*.78f,cvdTop=h*.85f,cvdBottom=h-10;
        if(bars.size()<3){text(canvas,"等待复查数据…",left+15,h/2,Color.LTGRAY,13);return;}
        double lo=Double.POSITIVE_INFINITY,hi=Double.NEGATIVE_INFINITY,maxV=1,loOi=Double.POSITIVE_INFINITY,hiOi=Double.NEGATIVE_INFINITY,loCvd=Double.POSITIVE_INFINITY,hiCvd=Double.NEGATIVE_INFINITY;
        for(WatchMetrics.Candle x:bars){lo=Math.min(lo,x.low);hi=Math.max(hi,x.high);maxV=Math.max(maxV,x.volume);
            if(Double.isFinite(x.oi)){loOi=Math.min(loOi,x.oi);hiOi=Math.max(hiOi,x.oi);}
            if(Double.isFinite(x.cvd)){loCvd=Math.min(loCvd,x.cvd);hiCvd=Math.max(hiCvd,x.cvd);}}
        if(!Double.isFinite(lo)||!Double.isFinite(hi))return;
        double pad=Math.max((hi-lo)*.08,hi*.00001);lo-=pad;hi+=pad;
        if(Double.isFinite(loOi)){double oiPad=Math.max((hiOi-loOi)*.1,hiOi*.00001);loOi-=oiPad;hiOi+=oiPad;}
        float step=(right-left)/bars.size();
        p.setStrokeWidth(1);p.setColor(Color.rgb(43,71,99));
        for(float y:new float[]{priceTop,priceBottom,volTop,volBottom,oiTop,oiBottom,cvdTop,cvdBottom})canvas.drawLine(left,y,right,y,p);
        text(canvas,"K线",left+3,14,Color.rgb(150,177,205),11);
        text(canvas,"量 买绿/卖红",left+3,volTop-4,Color.rgb(150,177,205),10);
        text(canvas,"OI",left+3,oiTop-4,Color.rgb(236,186,96),10);
        text(canvas,"CVD（USDT）",left+3,cvdTop-4,Color.rgb(68,212,158),10);
        for(int i=0;i<bars.size();i++){
            WatchMetrics.Candle b=bars.get(i);float x=left+(i+.5f)*step;
            float yHi=(float)(priceBottom-(b.high-lo)/(hi-lo)*(priceBottom-priceTop));
            float yLow=(float)(priceBottom-(b.low-lo)/(hi-lo)*(priceBottom-priceTop));
            float yOpen=(float)(priceBottom-(b.open-lo)/(hi-lo)*(priceBottom-priceTop));
            float yClose=(float)(priceBottom-(b.close-lo)/(hi-lo)*(priceBottom-priceTop));
            int tone=b.close>=b.open?Color.rgb(68,212,158):Color.rgb(248,108,135);
            p.setColor(tone);p.setStrokeWidth(1);canvas.drawLine(x,yHi,x,yLow,p);
            float bw=Math.max(1.7f,Math.min(6,step*.58f));p.setStyle(Paint.Style.FILL);
            canvas.drawRect(x-bw/2,Math.min(yOpen,yClose),x+bw/2,Math.max(Math.min(yOpen,yClose)+1,Math.max(yOpen,yClose)),p);
            float v=(float)(b.volume/maxV*(volBottom-volTop-1));
            if(Double.isFinite(b.buyBase)&&Double.isFinite(b.sellBase)){
                // Stacked base-volume column: active taker buys (green) + sells (red) = all volume.
                float buyHeight=(float)(b.buyBase/maxV*(volBottom-volTop-1));
                p.setColor(Color.rgb(67,207,150));canvas.drawRect(x-bw/2,volBottom-buyHeight,x+bw/2,volBottom,p);
                p.setColor(Color.rgb(242,110,139));canvas.drawRect(x-bw/2,volBottom-v,x+bw/2,volBottom-buyHeight,p);
            }else{p.setColor(tone);canvas.drawRect(x-bw/2,volBottom-v,x+bw/2,volBottom,p);}
        }
        if(Double.isFinite(loOi)&&hiOi>loOi){
            p.setColor(Color.rgb(244,192,98));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);
            android.graphics.Path path=new android.graphics.Path();boolean joined=false;
            for(int i=0;i<bars.size();i++){
                WatchMetrics.Candle b=bars.get(i);if(!Double.isFinite(b.oi)){joined=false;continue;}
                float x=left+(i+.5f)*step,y=(float)(oiBottom-(b.oi-loOi)/(hiOi-loOi)*(oiBottom-oiTop));
                if(joined)path.lineTo(x,y);else path.moveTo(x,y);joined=true;
            }
            canvas.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        }else text(canvas,"OI时间戳未对齐",left+42,oiTop+20,Color.LTGRAY,10);
        if(Double.isFinite(loCvd)&&Double.isFinite(hiCvd)){
            if(hiCvd==loCvd){hiCvd+=1;loCvd-=1;}
            p.setColor(Color.rgb(70,214,178));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);
            android.graphics.Path path=new android.graphics.Path();boolean joined=false;
            for(int i=0;i<bars.size();i++){
                WatchMetrics.Candle b=bars.get(i);if(!Double.isFinite(b.cvd)){joined=false;continue;}
                float xx=left+(i+.5f)*step;
                float yy=(float)(cvdBottom-(b.cvd-loCvd)/(hiCvd-loCvd)*(cvdBottom-cvdTop));
                if(joined)path.lineTo(xx,yy);else path.moveTo(xx,yy);joined=true;
            }
            canvas.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        }else text(canvas,"CVD样本不足",left+42,cvdTop+14,Color.LTGRAY,10);
        if(selected>=0&&selected<bars.size()){
            float x=left+(selected+.5f)*step;p.setColor(Color.rgb(166,192,215));p.setStrokeWidth(1);
            canvas.drawLine(x,priceTop,x,cvdBottom,p);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_DOWN&&e.getAction()!=MotionEvent.ACTION_UP)return true;
        if(e.getAction()==MotionEvent.ACTION_UP&&!bars.isEmpty()){
            selected=Math.max(0,Math.min(bars.size()-1,(int)((e.getX()-6)/(Math.max(1,getWidth()-14))*bars.size())));
            if(onSelect!=null)onSelect.accept(bars.get(selected));invalidate();performClick();
        }return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
